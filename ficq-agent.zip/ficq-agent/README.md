# FICQ Agent

**Personal AI Terminal Agent** untuk Acode di Android — CLI agent dengan tool system yang berjalan langsung dari terminal (Alpine Linux via proot), tanpa dependensi npm, tanpa root.

FICQ Agent memperkuat alur kerja Anda di ponsel: ia memahami instruksi bahasa natural, membaca struktur proyek, membaca/membuat/mengedit file, mencari teks, menjalankan perintah (selalu dengan persetujuan Anda), dan bekerja bertahap melalui agent loop dengan tool calling sungguhan — bukan sekadar chatbot.

---

## 1. Persyaratan Sistem

| Komponen | Persyaratan |
|---|---|
| Perangkat | Android dengan Acode + terminal (Alpine proot). Termux/Linux umum juga didukung |
| Runtime | Node.js **>= 16** (arsitektur apa pun, termasuk ARM 32-bit — kode 100% JavaScript, tanpa modul native) |
| RAM | ~30-50 MB saat berjalan (tanpa model lokal, semua inferensi di API) |
| Jaringan | Internet untuk mengakses API Gemini |
| Dependensi npm | **Tidak ada** — hanya modul bawaan Node (`fs`, `path`, `http`, `https`, `readline`, `child_process`, `os`, `crypto`) |

Cek kesiapan perangkat Anda:

```sh
sh scripts/diagnose.sh
```

## 2. Instalasi

```sh
# 1. Masuk ke terminal Acode, pastikan Node terpasang:
node --version          # butuh >= 16; kalau belum: apk add nodejs npm

# 2. Ekstrak paket ficq-agent.zip, lalu masuk ke foldernya:
cd /path/ke/ficq-agent

# 3. (Opsional) Jalankan installer - memverifikasi Node & memberi instruksi key:
sh scripts/install.sh

# 4. Uji cepat tanpa API key (mode demo, provider mock):
node index.js --demo
```

Tidak ada `npm install` — proyek sengaja dibuat nol dependensi agar aman untuk ARM 32-bit dan hemat ruang.

## 3. Konfigurasi API Key

API key **tidak pernah** ditulis di source code, tidak dicetak ke terminal, tidak masuk Git, tidak masuk log/riwayat percakapan, dan tidak muncul di pesan error.

1. Buat API key gratis di <https://aistudio.google.com/apikey>
2. Simpan dengan salah satu cara (pilih satu):

```sh
# Cara A - per sesi terminal (paling aman):
export GEMINI_API_KEY="key-anda"

# Cara A permanen - tambahkan ke ~/.profile atau ~/.bashrc lalu buka terminal baru:
echo 'export GEMINI_API_KEY="key-anda"' >> ~/.profile

# Cara B - file terpisah dengan permission 600 (input disembunyikan saat mengetik):
node index.js --set-key
```

3. Verifikasi tanpa menampilkan key:

```sh
node -e "const fs=require('fs');console.log(!!(process.env.GEMINI_API_KEY||(fs.existsSync(require('os').homedir()+'/.ficq/secret')&&fs.readFileSync(require('os').homedir()+'/.ficq/secret','utf8').trim())))"
```

**Catatan keamanan file secret:** di Android tanpa enkripsi disk, file lokal tetap dapat dibaca aplikasi ber-root atau jika perangkat diserang. Env var adalah mekanisme utama yang direkomendasikan. File secret tersimpan di `~/.ficq/secret` (chmod 600, otomatis diperbaiki bila permission longgar).

Variabel environment yang didukung: `GEMINI_API_KEY`, `GEMINI_MODEL` (ubah model), `GEMINI_BASE_URL` (proxy/kompatibel), `FICQ_PROVIDER` (`gemini`|`mock`).

## 4. Cara Menjalankan

```sh
cd ~/projects/proyek-anda        # workspace = folder proyek Anda
node /path/ke/ficq-agent/index.js

# Opsi berguna:
node index.js --workspace ~/projects/app   # set workspace
node index.js --model gemini-3.6-flash     # ganti model untuk sesi ini
node index.js --resume last                # lanjutkan sesi terakhir
node index.js --once "jelaskan struktur proyek ini"   # non-interaktif

# Opsional - alias permanen:
echo "alias ficq='node /path/ke/ficq-agent/index.js'" >> ~/.profile
```

Contoh instruksi: *"jelaskan struktur proyek ini"*, *"buat file utils.js berisi fungsi format tanggal"*, *"perbaiki bug di index.js lalu jalankan node index.js"*, *"cari semua penggunaan fetch lalu ringkas"*.

## 5. Daftar Perintah Internal

| Perintah | Fungsi |
|---|---|
| `/help` | Menampilkan bantuan |
| `/exit` | Keluar (sesi tersimpan otomatis) |
| `/clear` | Membersihkan tampilan terminal |
| `/reset` | Mengatur ulang sesi (konteks baru) |
| `/model` | Melihat atau mengubah model (`/model <id>`) |
| `/usage` | Melihat penggunaan token |
| `/tools` | Melihat daftar tools |
| `/workspace` | Melihat workspace aktif |
| `/history` | Melihat riwayat sesi (`/history <n>` = n pesan terakhir) |

`Ctrl+C` saat AI bekerja = batalkan langkah berjalan; saat idle = keluar.

## 6. Sistem Tools

| Tool | Fungsi | Persetujuan |
|---|---|---|
| `list_files` | Melihat isi direktori | Otomatis |
| `read_file` | Membaca file teks (menolak file rahasia) | Otomatis |
| `write_file` | Membuat / menimpa file | **Selalu** |
| `edit_file` | Mengubah bagian tertentu (old_text unik) | **Selalu** |
| `search_files` | Mencari teks/regex di proyek | Otomatis |
| `run_command` | Menjalankan perintah shell | **Selalu**; berisiko = ketik `ya` |
| `get_environment` | Info OS/arsitektur/RAM/Node | Otomatis |
| `analyze_project` | Analisis struktur & teknologi proyek | Otomatis |
| `run_tests` | Menjalankan test (deteksi otomatis/npm/pytest/make) | **Selalu** |
| `git_status` | Status Git (read-only) | Otomatis |

**Perlindungan yang aktif:**

- Semua path dipaksa tetap di dalam workspace (path traversal `../` dan symlink escape ditolak).
- File rahasia (`.env`, `id_rsa`, `*.pem`, `*key`, kredensial) **ditolak** oleh `read_file` — agent tidak dapat membacanya meskipun diminta model.
- `run_command`: perintah ditampilkan + penjelasan efek + persetujuan eksplisit; perintah berisiko (hapus, install, jaringan, sudo, git push, dll.) wajib mengetik `ya`. Perintah destruktif tidak pernah dijalankan otomatis.
- Environment child process dibersihkan dari variabel rahasia (`*_KEY`, `*_TOKEN`, `*_SECRET`, `PASSWORD`, `GEMINI*`).
- Output tool dibatasi (default 8000 karakter), durasi perintah dibatasi timeout, output stdout/stderr dibatasi 64 KB/stream.

## 7. Arsitektur & Keputusan Teknis

```
instruksi → Agent Core (loop) ⇄ Provider Gemini (REST v1beta generateContent)
                     ⇅                     + tool calling (functionDeclarations/
                 Tool Registry             functionCall/functionResponse)
            (validasi schema +              ⇅
             approval + batas)        10 tools (fs, terminal, proyek)
                     ⇅
       Memory (sesi JSON lokal, usage tracking,
       auto-compaction konteks panjang)
```

- **Bahasa/runtime: Node.js (CommonJS, tanpa dependensi).** Terminal Acode = Alpine proot; paket `nodejs` tersedia via `apk` untuk ARM 32/64-bit. Nol dependensi = tanpa kompilasi native, instalasi satu langkah, RAM rendah. Node >= 16 wajib (pakai `AbortController` global).
- **Provider: Gemini REST `v1beta/models/{model}:generateContent`** — stateless, cocok dengan agent loop yang mengelola history sendiri. Format baru `interactions` dapat ditambahkan sebagai provider lain (abstraksi di `src/providers/base.js`). `GEMINI_BASE_URL` memungkinkan proxy. Model default `gemini-4-hydrogen` (per Nov 2026, untuk agentic coding sehari-hari); **model adalah konfigurasi**, bukan kode — cek `/model`.
- **Agent loop:** maksimum 15 iterasi (dikonfigurasi), timeout request 120 s, retry otomatis maks 2× (429/5xx/network, backoff eksponensial), batas output tool, pemakaian token dilacak per sesi, konteks panjang diringkas otomatis (budget 6000 token estimasi).
- **Keamanan:** lapisan `src/tools/safety.js` + approval di Agent Core (lihat bagian 6).

## 8. Struktur Proyek

```
ficq-agent/
├── index.js                  # entry point & boot
├── package.json              # nol dependensi
├── config/default.json       # default non-rahasia (model, limit)
├── scripts/
│   ├── diagnose.sh           # audit lingkungan (aman, read-only)
│   └── install.sh            # verifikasi Node + petunjuk key
├── src/
│   ├── core/agent.js         # agent loop + sistem prompt
│   ├── core/context.js       # estimasi token + compaction
│   ├── providers/gemini.js   # REST Gemini (generateContent)
│   ├── providers/mock.js     # provider uji/demo tanpa key
│   ├── providers/base.js     # kontrak provider
│   ├── tools/registry.js     # registrasi + validasi schema
│   ├── tools/safety.js       # path sandbox + klasifikasi risiko
│   ├── tools/filesystem.js   # list/read/write/edit/search
│   ├── tools/terminal.js     # run_command + get_environment
│   ├── tools/project.js      # analyze_project/run_tests/git_status
│   ├── memory/session.js     # riwayat + persistensi
│   ├── cli/ui.js             # banner/spinner/pesan
│   ├── cli/repl.js           # REPL + perintah internal + approval
│   └── utils/http.js         # HTTP client timeout+retry
├── tests/run-tests.js        # 14 skenario (unit + integrasi mock HTTP)
└── data/sessions/            # riwayat sesi (dibuat runtime, di-gitignore)
```

## 9. Pengujian

```sh
node tests/run-tests.js
```

Menguji: konfigurasi & redaksi key, keamanan path/perintah, validasi registry, seluruh tool filesystem, agent loop (teks & tool calling), penolakan approval, batas iterasi, integrasi HTTP nyata ke server mock Gemini (header key, mapping `contents`, parsing `functionCall`/`functionResponse`), pemetaan error API (400/429+retry), persistensi sesi tanpa key, compaction konteks, dan tools terminal/proyek. Hasil saat rilis: **14/14 lulus**.

## 10. Troubleshooting

| Gejala | Penyebab & Solusi |
|---|---|
| `API key tidak valid (400)` | Key salah/typos. Set ulang env var atau `node index.js --set-key` |
| `Model ... tidak ditemukan` | ID model salah/kadaluarsa. Jalankan `/model` untuk daftar dari API |
| `Kuota/rate limit (429)` | Tunggu sebentar (retry otomatis 2× sudah berjalan); cek kuota di AI Studio |
| `Timeout: tidak ada respons` | Jaringan lambat; naikkan `requestTimeoutMs` di `config/default.json` |
| `Akses di luar workspace tidak diizinkan` | Agent sengaja dibatasi di workspace. Jalankan dari folder proyek atau pakai `--workspace` |
| `Node.js terlalu lama` | `apk add nodejs npm`; butuh Node >= 16 |
| Spinner/animasi mengganggu | Jalankan dengan `NO_COLOR=1` atau `FICQ_NO_COLOR=1` |
| Edit file gagal "tidak ditemukan/unik" | `old_text` harus persis (termasuk indentasi) dan unik; perluas konteksnya |

## 11. Batasan Teknis

- Agent berjalan di sandbox workspace: tidak mengedit file di luar workspace, tidak memodifikasi sistem tanpa Anda setujui — ini fitur keamanan, bukan kekurangan.
- Persetujuan `run_command` bergantung pada klasifikasi pola; perintah tak dikenal dianggap risiko sedang (tetap ditampilkan dan dimintai persetujuan).
- Estimasi token memakai aproksimasi panjang karakter (÷4), bukan tokenizer resmi — cukup untuk manajemen konteks, tidak untuk penagihan.
- Ringkasan konteks memakai panggilan API terpisah (berkualitas model sama); bila gagal, fallback membuang riwayat lama dengan catatan.
- Di ARM 32-bit lama, waktu startup Node bisa 2-5 detik — normal.
- File secret lokal bergantung pada keamanan filesystem perangkat (lihat bagian 3).

## 12. Pengembangan

Menambah provider baru: implementasikan `name()`, `currentModel()`, `listModels()`, `generate()` mengikuti kontrak `src/providers/base.js`, lalu daftarkan di `index.js`. Menambah tool baru: buat definisi di `src/tools/` dan panggil `registry.register({...})` — schema, validasi, batas output, dan persetujuan otomatis tertangani registry.

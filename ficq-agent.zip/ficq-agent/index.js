#!/usr/bin/env node
'use strict';

/**
 * FICQ Agent - Personal AI Terminal Agent untuk Acode/Android.
 * Entry point: parsing argumen, boot konfigurasi, provider, tools, REPL.
 *
 * Penggunaan:
 *   node index.js                     mode interaktif
 *   node index.js --workspace <dir>   set workspace
 *   node index.js --model <id>        set model (sesi ini)
 *   node index.js --resume last       lanjutkan sesi terakhir
 *   node index.js --once "prompt"     satu instruksi lalu keluar (non-interaktif)
 *   node index.js --provider mock --demo   demo tanpa API key
 *   node index.js --set-key           simpan API key ke ~/.ficq/secret (chmod 600)
 */

const fs = require('fs');
const path = require('path');
const readline = require('readline');

process.on('uncaughtException', (e) => {
  process.stderr.write('[ficq] Kesalahan tak terduga: ' + String((e && e.message) || e) + '\n');
  process.exit(1);
});
process.on('unhandledRejection', (e) => {
  process.stderr.write('[ficq] Kesalahan tak terduga: ' + String((e && (e.message || e)) || e) + '\n');
  process.exit(1);
});

const { Config, redact } = require('./src/config/config');
const { UI } = require('./src/cli/ui');
const { Repl } = require('./src/cli/repl');
const { AgentCore } = require('./src/core/agent');
const { SessionStore } = require('./src/memory/session');
const { ToolRegistry } = require('./src/tools/registry');
const { defineFilesystemTools } = require('./src/tools/filesystem');
const { defineTerminalTools } = require('./src/tools/terminal');
const { defineProjectTools } = require('./src/tools/project');
const { GeminiProvider } = require('./src/providers/gemini');
const { MockProvider } = require('./src/providers/mock');

const VERSION = '1.0.0';

const DEMO_SCRIPT = [
  {
    text:
      'Halo! Saya FICQ Agent dalam mode demo (provider mock, tanpa API key). ' +
      'Saya akan mencoba tool list_files untuk melihat isi workspace sekarang.',
  },
  { functionCalls: [{ name: 'list_files', args: { path: '.' } }] },
  {
    text:
      'Selesai - di atas adalah hasil list_files dari workspace Anda (lihat baris "› list_files"). ' +
      'Mode demo hanya menguji integrasi agent loop; untuk pekerjaan nyata jalankan dengan provider gemini dan API key Anda.',
  },
  { text: '(Demo selesai. Semua langkah agent loop sudah diuji: teks, tool calling, dan hasil tool.)' },
];

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') out.help = true;
    else if (a === '--version' || a === '-v') out.version = true;
    else if (a === '--set-key') out.setKey = true;
    else if (a === '--workspace' || a === '-w') out.workspace = argv[++i];
    else if (a === '--model' || a === '-m') out.model = argv[++i];
    else if (a === '--provider') out.provider = argv[++i];
    else if (a === '--resume') out.resume = argv[++i] || 'last';
    else if (a === '--once') out.once = argv[++i];
    else if (a === '--demo') out.demo = true;
    else if (a === '--no-check') out.noCheck = true;
    else if (!a.startsWith('-')) out.once = a; // argumen posisional = mode sekali-jalan
    else {
      process.stderr.write('[ficq] Argumen tidak dikenal: ' + a + '\n');
      out.help = true;
      out._badArg = true;
    }
  }
  return out;
}

function printHelp() {
  process.stdout.write(
    [
      'FICQ Agent v' + VERSION + ' - Personal AI Terminal Agent',
      '',
      'Penggunaan: node index.js [opsi] [instruksi-sekali-jalan]',
      '',
      'Opsi:',
      '  -h, --help          Tampilkan bantuan ini',
      '  -v, --version       Tampilkan versi',
      '  --set-key           Simpan API key Gemini ke ~/.ficq/secret (chmod 600)',
      '  -w, --workspace <d> Set direktori workspace (default: direktori sekarang)',
      '  -m, --model <id>    Set model untuk sesi ini (mis. gemini-4-hydrogen)',
      '  --provider <nama>   gemini (default) | mock (tanpa API key)',
      '  --resume <id|last>  Lanjutkan sesi tersimpan',
      '  --once "<prompt>"   Jalankan satu instruksi lalu keluar',
      '  --demo              Demo mode mock dengan skrip terjadwal',
      '  --no-check          Lewati pengecekan koneksi saat startup',
      '',
      'Environment: GEMINI_API_KEY, GEMINI_MODEL, GEMINI_BASE_URL, FICQ_PROVIDER',
      '',
    ].join('\n') + '\n'
  );
}

function printKeySetup(ui) {
  ui.error('API key Gemini belum dikonfigurasi.');
  process.stdout.write(
    [
      '',
      'Cara mengatur API key (pilih salah satu):',
      '  1. Buat API key gratis di: https://aistudio.google.com/apikey',
      '  2a. Sementara (per sesi terminal):',
      '        export GEMINI_API_KEY="key-anda"',
      '  2b. Permanen: tambahkan baris di atas ke ~/.profile atau ~/.bashrc,',
      '      lalu buka terminal baru.',
      '  2c. File terpisah (chmod 600):',
      '        node index.js --set-key',
      '  3. Jalankan lagi: node index.js',
      '',
      'Key TIDAK PERNAH ditampilkan atau dicatat agent. Verifikasi tanpa mencetak:',
      '  node -e "console.log(!!(process.env.GEMINI_API_KEY||require(\'fs\').readFileSync(require(\'os\').homedir()+\'/.ficq/secret\',\'utf8\')))"',
      '',
    ].join('\n') + '\n'
  );
}

function setKeyFlow(config, ui) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
  rl.output.mute();
  rl.question('Tempel API key Gemini lalu tekan Enter (input disembunyikan): ', (key) => {
    rl.output.unmute();
    rl.close();
    const t = String(key || '').trim();
    if (!t) {
      ui.error('Key kosong - dibatalkan.');
      process.exit(1);
    }
    const p = config.saveApiKey(t);
    ui.info('API key tersimpan di ' + p + ' (permission 600). Key tidak akan ditampilkan kembali.');
    ui.warn(
      'Catatan keamanan: di Android tanpa enkripsi disk, file lokal tetap bisa dibaca ' +
        'aplikasi ber-root atau jika perangkat diserang. Env var GEMINI_API_KEY tetap paling aman.'
    );
    process.exit(0);
  });
}

async function checkConnection(provider, ui) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 8000);
  try {
    const models = await provider.listModels(ac.signal);
    return 'Connected (' + models.length + ' model tersedia)';
  } catch (e) {
    ui.warn('Pengecekan koneksi awal gagal: ' + redact((e && e.message) || e));
    return 'API key terpasang - koneksi belum terverifikasi';
  } finally {
    clearTimeout(t);
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    printHelp();
    process.exit(args._badArg ? 1 : 0);
  }
  if (args.version) {
    process.stdout.write('FICQ Agent v' + VERSION + '\n');
    process.exit(0);
  }

  const root = __dirname;
  const ui = new UI();

  // Workspace: default = direktori saat ini; wajib ada
  const workspace = path.resolve(args.workspace || process.cwd());
  if (!fs.existsSync(workspace)) {
    ui.error('Workspace tidak ditemukan: ' + workspace);
    process.exit(1);
  }
  process.chdir(workspace);

  const config = new Config({ projectRoot: root });
  if (args.model) config.values.model = args.model;
  if (args.noCheck) config.values.checkConnectionOnStart = false;

  if (args.setKey) return setKeyFlow(config, ui);

  // ---------------------------------------------------------------- provider
  const providerName = args.provider || config.get('provider');
  let provider;
  if (providerName === 'mock') {
    provider = new MockProvider({ script: args.demo ? DEMO_SCRIPT : [{ text: '(mock) Siap.' }] });
  } else if (providerName === 'gemini') {
    const { key, source, warnings } = config.resolveApiKey();
    for (const w of warnings) ui.warn(redact(w));
    if (!key) {
      printKeySetup(ui);
      process.exit(1);
    }
    if (source === 'env') ui.info('API key: terpasang via environment variable');
    if (source === 'file') ui.info('API key: terpasang via file ~/.ficq/secret (permission 600)');
    provider = new GeminiProvider({
      apiKey: key,
      model: config.get('model'),
      baseUrl: config.get('baseUrl'),
      config,
    });
  } else {
    ui.error('Provider tidak dikenal: ' + providerName + ' (pilihan: gemini, mock)');
    process.exit(1);
  }

  // ---------------------------------------------------------------- tools
  const registry = new ToolRegistry();
  defineFilesystemTools(registry, config);
  defineTerminalTools(registry, config);
  defineProjectTools(registry, config);

  // ---------------------------------------------------------------- memori
  const store = new SessionStore({ dir: path.join(root, 'data', 'sessions') });
  let session = null;
  if (args.resume) {
    session = args.resume === 'last' ? store.latest() : store.load(args.resume);
    if (!session) {
      ui.error('Sesi tidak ditemukan: ' + args.resume + '. Cek /history untuk daftar sesi.');
      process.exit(1);
    }
    ui.info('Melanjutkan sesi: ' + session.id);
  } else {
    session = store.create({ model: config.get('model'), provider: provider.name(), workspace });
  }
  session.setModel(provider.currentModel());

  const agent = new AgentCore({ provider, registry, memory: session, config, ui });

  // ---------------------------------------------------------------- mode --once
  if (args.once) {
    if (providerName === 'mock') {
      agent.setApprover(async () => true); // mock: persetujuan otomatis (aman utk demo/test)
    } else {
      agent.setApprover(async (req) => {
        ui.warn('Tool "' + req.name + '" butuh persetujuan - di mode --once otomatis DITOLAK. Gunakan mode interaktif.');
        return false;
      });
    }
    try {
      const answer = await agent.submit(String(args.once));
      ui.assistant(answer);
      process.exitCode = 0;
    } catch (e) {
      ui.error(redact((e && e.message) || String(e)));
      process.exitCode = 1;
    } finally {
      store.save(session);
    }
    return;
  }

  // ---------------------------------------------------------------- REPL
  const repl = new Repl({ config, provider, registry, memory: session, sessionStore: store, ui });
  repl.attachAgent(agent);

  let status = 'siap (mode mock)';
  if (providerName === 'gemini' && config.get('checkConnectionOnStart')) {
    status = await checkConnection(provider, ui);
  }
  repl.showBanner({ provider: provider.name(), model: provider.currentModel(), status, workspace });
  repl.start();
}

main();

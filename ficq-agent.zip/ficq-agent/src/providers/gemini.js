'use strict';

/**
 * Provider Google Gemini via REST API v1beta (generateContent).
 * - Tanpa SDK/dependensi eksternal (hanya modul https bawaan Node).
 * - Model dapat dikonfigurasi (config/default.json, ~/.ficq/config.json, atau env GEMINI_MODEL).
 * - API key dikirim via header x-goog-api-key, TIDAK PERNAH di-log.
 */

const { requestJson } = require('../utils/http');
const { redact } = require('../config/config');

const TYPE_MAP = {
  string: 'STRING', number: 'NUMBER', integer: 'INTEGER',
  boolean: 'BOOLEAN', array: 'ARRAY', object: 'OBJECT',
};

class GeminiProvider {
  constructor({ apiKey, model, baseUrl, config }) {
    this.apiKey = apiKey;
    this.model = model;
    this.baseUrl = String(baseUrl || 'https://generativelanguage.googleapis.com').replace(/\/+$/, '');
    this.config = config;
  }

  name() {
    return 'gemini';
  }

  currentModel() {
    return this.model;
  }

  _headers() {
    return { 'Content-Type': 'application/json', 'x-goog-api-key': this.apiKey };
  }

  /** Daftar model yang mendukung generateContent (untuk validasi & perintah /model). */
  async listModels(signal) {
    const url = this.baseUrl + '/v1beta/models?pageSize=200';
    const res = await requestJson({
      url,
      method: 'GET',
      headers: this._headers(),
      timeoutMs: 20000,
      signal,
      retries: 1,
    });
    this._throwIfApiError(res);
    const models = (res.json && res.json.models) || [];
    return models
      .filter((m) => (m.supportedGenerationMethods || []).includes('generateContent'))
      .map((m) => ({
        id: String(m.name || '').replace(/^models\//, ''),
        displayName: m.displayName || '',
        inputTokenLimit: m.inputTokenLimit || null,
      }));
  }

  /** Satu langkah generate: teks dan/atau function calls. */
  async generate({ system, history, toolDecls, signal, onRetry }) {
    const contents = (history || []).map((e) => mapEntry(e)).filter(Boolean);
    const body = {
      contents,
      systemInstruction: { parts: [{ text: system }] },
      generationConfig: {
        temperature: this.config.get('temperature'),
        maxOutputTokens: this.config.get('maxOutputTokens'),
      },
    };
    if (toolDecls && toolDecls.length) {
      body.tools = [{ functionDeclarations: toolDecls }];
    }

    const url = this.baseUrl + '/v1beta/models/' + encodeURIComponent(this.model) + ':generateContent';
    const res = await requestJson({
      url,
      method: 'POST',
      headers: this._headers(),
      body,
      timeoutMs: this.config.get('requestTimeoutMs'),
      retries: this.config.get('maxRetries'),
      retryDelayMs: this.config.get('retryDelayMs'),
      signal,
      onRetry,
    });
    this._throwIfApiError(res);
    return this._parse(res.json);
  }

  _throwIfApiError(res) {
    if (res.status >= 200 && res.status < 300) return;
    const msg = (res.json && res.json.error && res.json.error.message) || 'HTTP ' + res.status;
    let friendly;
    if (res.status === 400 && /api key not valid/i.test(msg)) {
      friendly = 'API key tidak valid (400). Periksa env GEMINI_API_KEY atau file ~/.ficq/secret.';
    } else if (res.status === 404 || (res.status === 400 && /not found/i.test(msg) && /model/i.test(msg))) {
      friendly = 'Model "' + this.model + '" tidak ditemukan (HTTP ' + res.status + '). Gunakan /model untuk melihat model yang tersedia.';
    } else if (res.status === 403) {
      friendly = 'Akses ditolak (403): ' + msg;
    } else if (res.status === 429) {
      friendly = 'Kuota/rate limit terlampaui (429): ' + msg;
    } else if (res.status >= 500) {
      friendly = 'Server Gemini bermasalah (' + res.status + '): ' + msg;
    } else {
      friendly = 'HTTP ' + res.status + ': ' + msg;
    }
    const err = new Error(redact(friendly));
    err.status = res.status;
    throw err;
  }

  _parse(data) {
    if (data && data.promptFeedback && data.promptFeedback.blockReason && !(data.candidates || []).length) {
      throw new Error('Permintaan diblokir filter keamanan Gemini: ' + data.promptFeedback.blockReason);
    }
    const cand = data && data.candidates && data.candidates[0];
    const parts = (cand && cand.content && cand.content.parts) || [];
    let text = '';
    const functionCalls = [];
    for (const p of parts) {
      if (typeof p.text === 'string') text += p.text;
      if (p.functionCall && p.functionCall.name) {
        functionCalls.push({ name: p.functionCall.name, args: p.functionCall.args || {} });
      }
    }
    if (!text && !functionCalls.length && cand && cand.finishReason === 'MAX_TOKENS') {
      text = '[Output terpotong oleh batas maxOutputTokens. Minta saya melanjutkan atau naikkan maxOutputTokens di konfigurasi.]';
    }
    const u = (data && data.usageMetadata) || {};
    return {
      text: text.trim(),
      functionCalls,
      finishReason: (cand && cand.finishReason) || null,
      usage: {
        input: u.promptTokenCount || 0,
        output: u.candidatesTokenCount || 0,
        total: u.totalTokenCount || 0,
      },
    };
  }
}

/** Map entri internal -> format contents Gemini. */
function mapEntry(e) {
  if (!e) return null;
  if (e.type === 'text') {
    if (!e.text) return null;
    return { role: e.role === 'model' ? 'model' : 'user', parts: [{ text: e.text }] };
  }
  if (e.type === 'calls') {
    return {
      role: 'model',
      parts: (e.calls || []).map((c) => ({ functionCall: { name: c.name, args: c.args || {} } })),
    };
  }
  if (e.type === 'tool') {
    return {
      role: 'user',
      parts: [{ functionResponse: { name: e.name, response: e.response || { ok: false } } }],
    };
  }
  if (e.type === 'summary') {
    return { role: 'user', parts: [{ text: '[Ringkasan percakapan sebelumnya]\n' + (e.text || '') }] };
  }
  return null;
}

module.exports = { GeminiProvider };

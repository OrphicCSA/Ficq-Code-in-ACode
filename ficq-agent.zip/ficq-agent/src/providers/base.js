'use strict';

/**
 * Kontrak provider LLM.
 * Provider baru (mis. format "interactions", OpenAI-compatible) cukup
 * mengimplementasikan: name(), currentModel(), listModels(), generate().
 *
 * generate({system, history, toolDecls, signal, onRetry}) harus mengembalikan:
 * {
 *   text: string,
 *   functionCalls: [{name, args}],
 *   finishReason: string|null,
 *   usage: {input, output, total}
 * }
 *
 * history adalah entri internal:
 *   {type:'text', role:'user'|'model', text}
 *   {type:'calls', role:'model', calls:[{name, args}]}
 *   {type:'tool', name, response(object)}
 *   {type:'summary', text}
 */
class BaseProvider {
  name() {
    return 'base';
  }

  currentModel() {
    throw new Error('currentModel() belum diimplementasikan');
  }

  async listModels() {
    throw new Error('listModels() belum diimplementasikan');
  }

  async generate() {
    throw new Error('generate() belum diimplementasikan');
  }
}

module.exports = { BaseProvider };

'use strict';

/**
 * Provider MOCK untuk pengujian dan demo tanpa API key asli.
 * Menerima "script": daftar langkah yang dijawab berurutan.
 *
 * Langkah:
 *   { text: '...' }                          -> jawaban teks
 *   { functionCalls: [{name, args}] }        -> permintaan tool call
 *   { error: {status, message} }             -> simulasi error API
 *   { waitMs: 300, text: '...' }             -> simulasi delay
 */

class MockProvider {
  constructor({ script }) {
    this.script = Array.isArray(script) ? script.slice() : [];
    this.calls = []; // riwayat generate() untuk asersi test
  }

  name() {
    return 'mock';
  }

  currentModel() {
    return 'mock-1';
  }

  async listModels() {
    return [
      { id: 'mock-1', displayName: 'Mock Model 1', inputTokenLimit: 100000 },
      { id: 'mock-2', displayName: 'Mock Model 2', inputTokenLimit: 200000 },
    ];
  }

  async generate({ system, history, toolDecls, signal }) {
    if (signal && signal.aborted) throw new Error('Dibatalkan oleh pengguna');
    this.calls.push({
      systemLen: system ? system.length : 0,
      history: JSON.parse(JSON.stringify(history || [])),
      toolDecls: toolDecls ? toolDecls.map((d) => d.name) : [],
    });
    const step = this.script.shift();
    if (!step) throw new Error('Mock script habis - tambahkan langkah pada test');
    if (step.error) {
      const e = new Error(step.error.message || 'Mock error');
      e.status = step.error.status || 500;
      throw e;
    }
    if (step.waitMs) await new Promise((r) => setTimeout(r, step.waitMs));
    return {
      text: step.text || '',
      functionCalls: step.functionCalls || [],
      finishReason: 'STOP',
      usage: step.usage || { input: 120, output: 40, total: 160 },
    };
  }
}

module.exports = { MockProvider };

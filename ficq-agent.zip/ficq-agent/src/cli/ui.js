'use strict';

/**
 * Utilitas tampilan terminal: banner, spinner ringan, dan pencetak pesan.
 * Dirancang untuk layar smartphone kecil: sedikit warna, tanpa animasi berat.
 */

const useColor = Boolean(process.stdout.isTTY) && !process.env.NO_COLOR && !process.env.FICQ_NO_COLOR;

const C = {
  dim: (s) => (useColor ? '\x1b[2m' + s + '\x1b[0m' : s),
  bold: (s) => (useColor ? '\x1b[1m' + s + '\x1b[0m' : s),
  green: (s) => (useColor ? '\x1b[32m' + s + '\x1b[0m' : s),
  red: (s) => (useColor ? '\x1b[31m' + s + '\x1b[0m' : s),
  yellow: (s) => (useColor ? '\x1b[33m' + s + '\x1b[0m' : s),
  cyan: (s) => (useColor ? '\x1b[36m' + s + '\x1b[0m' : s),
};

const FRAMES_UNICODE = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
const FRAMES_ASCII = ['|', '/', '-', '\\'];

function center(s, width) {
  s = String(s);
  const pad = Math.max(0, Math.floor((width - s.length) / 2));
  return ' '.repeat(pad) + s;
}

class UI {
  constructor() {
    this.spinnerTimer = null;
    this.frameIdx = 0;
    this.label = '';
  }

  prompt(text) {
    return C.cyan(text);
  }

  banner({ provider, model, status, workspace }) {
    const W = 38;
    const top = '╭' + '─'.repeat(W) + '╮';
    const bot = '╰' + '─'.repeat(W) + '╯';
    const rows = [];
    rows.push(C.cyan(top));
    rows.push(C.cyan('│') + C.bold(center('FICQ AGENT', W)) + C.cyan('│'));
    rows.push(C.cyan('│') + C.dim(center('Personal AI Terminal Agent', W)) + C.cyan('│'));
    rows.push(C.cyan(bot));
    rows.push('');
    rows.push('  ' + C.dim('Provider : ') + provider);
    rows.push('  ' + C.dim('Model    : ') + model);
    let statusStr = String(status || '-');
    if (/connected/i.test(statusStr)) statusStr = C.green(statusStr);
    else if (/belum|gagal/i.test(statusStr)) statusStr = C.yellow(statusStr);
    rows.push('  ' + C.dim('Status   : ') + statusStr);
    rows.push('  ' + C.dim('Workspace: ') + workspace);
    rows.push('');
    process.stdout.write(rows.join('\n') + '\n');
  }

  info(msg) {
    this.progressEnd();
    process.stdout.write(C.dim('[i] ') + msg + '\n');
  }

  warn(msg) {
    this.progressEnd();
    process.stdout.write(C.yellow('[!] ') + msg + '\n');
  }

  error(msg) {
    this.progressEnd();
    process.stdout.write(C.red('[x] ') + C.red(String(msg)) + '\n');
  }

  assistant(text) {
    this.progressEnd();
    process.stdout.write('\n' + C.bold('AI > ') + String(text) + '\n\n');
  }

  /** Indikator proses saat AI bekerja (ringan: 1 baris, update 120ms). */
  progress(label) {
    if (!process.stdout.isTTY) return; // tanpa TTY: diam (log tetap bersih)
    if (!this.spinnerTimer) {
      const frames = /[\u2190-\u2FFF]/u.test('⠋') ? FRAMES_UNICODE : FRAMES_ASCII;
      this.spinnerTimer = setInterval(() => {
        this.frameIdx = (this.frameIdx + 1) % frames.length;
        process.stdout.write('\r' + frames[this.frameIdx] + ' ' + this.label + '\x1b[K');
      }, 120);
    }
    this.label = label;
  }

  progressEnd() {
    if (this.spinnerTimer) {
      clearInterval(this.spinnerTimer);
      this.spinnerTimer = null;
      if (process.stdout.isTTY) process.stdout.write('\r\x1b[K');
    }
    this.label = '';
  }

  toolStart(name, desc) {
    this.progressEnd();
    process.stdout.write(C.dim('  › ' + name + ': ' + desc) + '\n');
    this.progress('menjalankan ' + name + '...');
  }

  toolDone(name, ok, note) {
    this.progressEnd();
    if (ok) process.stdout.write(C.dim('  ✓ ' + name + ' selesai') + '\n');
    else process.stdout.write(C.red('  ✗ ' + name + (note ? ': ' + note : ' gagal')) + '\n');
  }

  approvalBox(name, describe, highRisk) {
    const lines = [];
    lines.push('  ' + C.bold('┌─ PERSETUJUAN DIPERLUKAN ' + '─'.repeat(14)));
    lines.push('  │ ' + C.dim('Tool') + ' : ' + name);
    lines.push('  │ ' + C.dim('Aksi') + ' : ' + describe);
    if (highRisk) lines.push('  │ ' + C.yellow('PERINGATAN: aksi berisiko - baca dengan teliti'));
    lines.push('  ' + C.bold('└' + '─'.repeat(40)));
    process.stdout.write(lines.join('\n') + '\n');
  }
}

module.exports = { UI, C };

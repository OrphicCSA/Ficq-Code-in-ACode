'use strict';

/**
 * REPL CLI: loop input pengguna, perintah internal, dan alur persetujuan tool.
 *
 * Input dikelola lewat event 'line' + antrian internal: baris yang diketik
 * saat agent bekerja dimasukkan ke antrian dan diproses setelah tugas
 * selesai (tidak ada input yang hilang, termasuk saat input di-pipe).
 */

const readline = require('readline');
const { redact } = require('../config/config');
const { C } = require('./ui');
const { estimateHistoryTokens } = require('../core/context');

const COMMANDS = ['/help', '/exit', '/clear', '/reset', '/model', '/usage', '/tools', '/workspace', '/history'];

class Repl {
  constructor({ config, provider, registry, memory, sessionStore, ui }) {
    this.config = config;
    this.provider = provider;
    this.registry = registry;
    this.memory = memory;
    this.sessionStore = sessionStore;
    this.ui = ui;
    this.rl = null;
    this.exiting = false;
    this.busy = false;
    this.ac = null;
    this.pending = []; // baris yang menunggu diproses
    this.lineWaiter = null; // resolver untuk pertanyaan (approval)
    this.eof = false;
    this.bannerArgs = null;
  }

  attachAgent(agent) {
    this.agent = agent;
    agent.setApprover((req) => this._approve(req));
  }

  showBanner(args) {
    this.bannerArgs = args;
    this.ui.banner(args);
  }

  start() {
    this.rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: Boolean(process.stdin.isTTY),
      completer: (line) => [COMMANDS.filter((c) => c.startsWith(line)), line],
    });
    this.rl.on('line', (line) => this._onInput(line));
    this.rl.on('close', () => {
      // EOF (Ctrl+D) atau rl.close()
      this.eof = true;
      if (this.exiting) process.exit(0);
      if (this.lineWaiter) {
        const w = this.lineWaiter;
        this.lineWaiter = null;
        w(''); // jawaban kosong = tolak persetujuan
      }
      this._maybeFinish();
    });
    this.rl.on('SIGINT', () => {
      if (this.busy && this.ac) {
        this.ac.abort();
        this.ui.warn('(membatalkan langkah yang sedang berjalan...)');
      } else {
        this._exit();
      }
    });
    this.ui.info('Ketik /help untuk daftar perintah. Ctrl+C membatalkan langkah berjalan / keluar.');
    this._showPrompt();
  }

  // ---------------------------------------------------------------- alur input

  _showPrompt() {
    if (!this.exiting && !this.eof) process.stdout.write(this.ui.prompt('You > '));
  }

  _onInput(line) {
    if (this.exiting) return;
    if (this.lineWaiter) {
      const w = this.lineWaiter;
      this.lineWaiter = null;
      w(line);
      return;
    }
    if (this.busy) {
      this.pending.push(line);
      this.ui.info('(masuk antrian: ' + String(line).trim().slice(0, 40) + ')');
      return;
    }
    this._handleLine(line);
  }

  async _handleLine(line) {
    const t = String(line || '').trim();
    if (!t) return this._showPrompt();
    if (t.startsWith('/')) {
      try {
        await this._command(t);
      } catch (e) {
        this.ui.error(redact(e.message));
      }
      if (!this.exiting) this._maybeFinish() || this._showPrompt();
      return;
    }
    this._runAgent(t);
  }

  _runAgent(text) {
    this.busy = true;
    this.ac = new AbortController();
    (async () => {
      try {
        const answer = await this.agent.submit(text, this.ac.signal);
        this.ui.assistant(answer);
      } catch (e) {
        if (/Dibatalkan oleh pengguna/i.test(String(e && e.message))) this.ui.warn('Dibatalkan oleh pengguna.');
        else this.ui.error(redact((e && e.message) || String(e)));
      } finally {
        this.busy = false;
        this.ui.progressEnd();
        this._save();
        const next = !this.exiting && this.pending.length ? this.pending.shift() : null;
        if (next) this._handleLine(next);
        else this._maybeFinish() || this._showPrompt();
      }
    })();
  }

  /** Jika EOF sudah terjadi dan tidak ada pekerjaan tersisa: simpan & keluar. */
  _maybeFinish() {
    if (this.eof && !this.busy && !this.lineWaiter && !this.pending.length && !this.exiting) {
      this._save();
      this.ui.info('Sesi tersimpan. Sampai jumpa!');
      this.exiting = true;
      setTimeout(() => process.exit(0), 100);
      return true;
    }
    return false;
  }

  _save() {
    try {
      if (this.sessionStore && this.memory) this.sessionStore.save(this.memory);
    } catch (e) {
      this.ui.warn('Gagal menyimpan sesi: ' + e.message);
    }
  }

  _exit() {
    this._save();
    this.ui.info('Sesi tersimpan. Sampai jumpa!');
    this.exiting = true;
    try {
      this.rl.close();
    } catch (_) { /* sudah tertutup */ }
    setTimeout(() => process.exit(0), 100);
  }

  // ---------------------------------------------------------------- approval

  _askRaw(q) {
    process.stdout.write(q);
    return new Promise((resolve) => {
      this.lineWaiter = resolve;
    });
  }

  async _approve({ name, describe, highRisk }) {
    this.ui.progressEnd();
    this.ui.approvalBox(name, describe, highRisk);
    const q = highRisk
      ? '  ' + C.yellow('Ketik "ya" untuk MENYETUJUI (berisiko), lainnya untuk tolak: ')
      : '  ' + C.dim('Setujui eksekusi? [y/n]: ');
    const ans = await this._askRaw(q);
    const t = String(ans || '').trim().toLowerCase();
    return highRisk ? t === 'ya' : t === 'y' || t === 'ya' || t === 'yes';
  }

  // ---------------------------------------------------------------- perintah internal

  async _command(t) {
    const parts = t.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const arg = parts.slice(1).join(' ');

    switch (cmd) {
      case '/help':
        this._printHelp();
        break;
      case '/exit':
        this._exit();
        break;
      case '/clear':
        process.stdout.write('\x1b[2J\x1b[1;1H');
        if (this.bannerArgs) this.ui.banner(this.bannerArgs);
        break;
      case '/reset': {
        const s = this.sessionStore.create({
          model: this.provider.currentModel(),
          provider: this.provider.name(),
          workspace: process.cwd(),
        });
        this.memory = s;
        if (this.agent) this.agent.memory = s;
        this.ui.info('Sesi baru dimulai: ' + s.id);
        break;
      }
      case '/model':
        await this._cmdModel(arg);
        break;
      case '/usage': {
        const u = this.memory.usage;
        const est = estimateHistoryTokens(this.memory.entries());
        this.ui.info('Permintaan API : ' + u.apiRequests);
        this.ui.info('Token masuk   : ' + u.promptTokens);
        this.ui.info('Token keluar  : ' + u.completionTokens);
        this.ui.info('Total token   : ' + u.totalTokens);
        this.ui.info('Tool dijalankan: ' + u.toolExecutions);
        this.ui.info('Estimasi konteks saat ini: ~' + est + ' token (budget ' + this.config.get('contextTokenBudget') + ')');
        break;
      }
      case '/tools': {
        this.ui.info('Tools terdaftar (' + this.registry.names().length + '):');
        for (const tool of this.registry.list()) {
          const badge = tool.needsApproval ? C.yellow('[persetujuan]') : C.dim('[otomatis]');
          this.ui.info('  ' + badge + ' ' + C.bold(tool.name) + ' - ' + String(tool.description).slice(0, 80));
        }
        break;
      }
      case '/workspace':
        this.ui.info('Workspace aktif: ' + process.cwd());
        break;
      case '/history':
        this._cmdHistory(arg);
        break;
      default:
        this.ui.error('Perintah tidak dikenal: ' + cmd + '. Ketik /help.');
    }
  }

  _printHelp() {
    const rows = [
      ['/help', 'Menampilkan bantuan'],
      ['/exit', 'Keluar dari agent (sesi tersimpan otomatis)'],
      ['/clear', 'Membersihkan tampilan terminal'],
      ['/reset', 'Mengatur ulang sesi (mulai konteks baru)'],
      ['/model', 'Melihat atau mengubah model (/model <id>)'],
      ['/usage', 'Melihat penggunaan token'],
      ['/tools', 'Melihat daftar tools'],
      ['/workspace', 'Melihat workspace aktif'],
      ['/history', 'Melihat riwayat sesi (/history <n> = n pesan terakhir)'],
    ];
    this.ui.info('Perintah internal:');
    for (const [c, d] of rows) process.stdout.write('  ' + C.bold(c.padEnd(12)) + C.dim(d) + '\n');
    process.stdout.write('\n' + C.dim('Contoh instruksi: "buat file hello.js yang mencetak halo", "perbaiki bug di index.js", "jalankan npm test"') + '\n');
  }

  async _cmdModel(arg) {
    if (!arg) {
      this.ui.info('Model aktif: ' + C.bold(this.provider.currentModel()));
      this.ui.info('Mengambil daftar model dari API...');
      try {
        const models = await this.provider.listModels();
        const interesting = models
          .filter((m) => /flash|pro|carbon|neon|hydrogen|argon/i.test(m.id))
          .slice(0, 30);
        for (const m of interesting) {
          process.stdout.write('  ' + m.id + C.dim(m.inputTokenLimit ? '  (~' + Math.round(m.inputTokenLimit / 1000) + 'k konteks)' : '') + '\n');
        }
        this.ui.info('Total model generateContent: ' + models.length + '. Ganti dengan: /model <id>');
      } catch (e) {
        this.ui.warn('Gagal mengambil daftar model: ' + redact(e.message));
      }
      return;
    }
    const id = arg.trim();
    try {
      const models = await this.provider.listModels();
      if (!models.some((m) => m.id === id)) {
        this.ui.warn('Model "' + id + '" tidak ada di daftar API. Tetap disimpan, tapi mungkin gagal saat dipakai.');
      }
    } catch (_) {
      this.ui.warn('Tidak dapat memvalidasi model (jaringan/API?). Model tetap disimpan tanpa validasi.');
    }
    this.provider.model = id;
    this.memory.setModel(id);
    const p = this.config.setPersist('model', id);
    this.ui.info('Model diganti ke ' + C.bold(id) + ' (tersimpan di ' + p + ')');
    if (this.bannerArgs) this.bannerArgs.model = id;
  }

  _cmdHistory(arg) {
    const n = parseInt(arg, 10);
    if (Number.isFinite(n) && n > 0) {
      const entries = this.memory.entries().slice(-n);
      if (!entries.length) return this.ui.info('(riwayat kosong)');
      for (const e of entries) {
        if (e.type === 'text') {
          process.stdout.write('  ' + (e.role === 'user' ? C.cyan('[Anda]') : C.green('[AI]')) + ' ' + String(e.text || '').slice(0, 120).replace(/\n/g, ' ') + '\n');
        } else if (e.type === 'calls') {
          this.ui.info('[AI->tool] ' + (e.calls || []).map((c) => c.name).join(', '));
        } else if (e.type === 'tool') {
          this.ui.info('[hasil ' + e.name + '] ' + (e.response && e.response.ok ? 'ok' : 'gagal'));
        } else if (e.type === 'summary') {
          this.ui.info('[ringkasan] ' + String(e.text || '').slice(0, 120));
        }
      }
      return;
    }
    const list = this.sessionStore.list().slice(0, 10);
    if (!list.length) return this.ui.info('Belum ada sesi tersimpan.');
    this.ui.info('Sesi tersimpan (terbaru dulu):');
    for (const s of list) {
      const d = new Date(s.updatedAt || s.createdAt || Date.now());
      process.stdout.write(
        '  ' + C.bold(s.id) + C.dim('  ' + d.toISOString().slice(0, 16).replace('T', ' ') + '  ' + s.entries + ' entri  ' + s.totalTokens + ' token') + '\n    ' + C.dim(s.preview) + '\n'
      );
    }
    this.ui.info('Lanjutkan sesi: node index.js --resume <id> (atau --resume last)');
  }
}

module.exports = { Repl, COMMANDS };

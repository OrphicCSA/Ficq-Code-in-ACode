'use strict';

/**
 * Klien HTTP JSON tanpa dependensi eksternal (hanya modul bawaan Node.js).
 * Kompatibel Node >= 16 pada arsitektur apa pun, termasuk ARM 32-bit.
 */

const http = require('http');
const https = require('https');
const { URL } = require('url');

const MAX_RESPONSE_BYTES = 20 * 1024 * 1024; // 20 MB

const RETRYABLE_NET = /ECONNRESET|ECONNREFUSED|ENOTFOUND|ETIMEDOUT|EAI_AGAIN|socket hang up|network|Timeout/i;

function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    if (signal) {
      const onAbort = () => {
        clearTimeout(t);
        reject(new Error('Dibatalkan oleh pengguna'));
      };
      if (signal.aborted) onAbort();
      else signal.addEventListener('abort', onAbort, { once: true });
    }
  });
}

function rawRequest({ url, method = 'GET', headers = {}, body = null, timeoutMs = 120000, signal = null }) {
  return new Promise((resolve, reject) => {
    let u;
    try {
      u = new URL(url);
    } catch (e) {
      return reject(new Error('URL tidak valid: ' + e.message));
    }
    const mod = u.protocol === 'http:' ? http : https;
    const finalHeaders = Object.assign({}, headers);
    if (body) finalHeaders['Content-Length'] = Buffer.byteLength(body);

    const req = mod.request(u, { method, headers: finalHeaders, timeout: timeoutMs }, (res) => {
      const chunks = [];
      let size = 0;
      let settled = false;
      res.on('data', (c) => {
        if (settled) return;
        size += c.length;
        if (size > MAX_RESPONSE_BYTES) {
          settled = true;
          req.destroy();
          reject(new Error('Ukuran respons melebihi batas 20 MB'));
          return;
        }
        chunks.push(c);
      });
      res.on('end', () => {
        if (settled) return;
        settled = true;
        resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString('utf8') });
      });
      res.on('error', (e) => {
        if (!settled) {
          settled = true;
          reject(e);
        }
      });
    });

    req.on('timeout', () => {
      req.destroy(new Error('Timeout: tidak ada respons dalam ' + Math.round(timeoutMs / 1000) + ' detik'));
    });
    req.on('error', (e) => reject(e));

    if (signal) {
      const onAbort = () => req.destroy(new Error('Dibatalkan oleh pengguna'));
      if (signal.aborted) {
        onAbort();
        return;
      }
      signal.addEventListener('abort', onAbort, { once: true });
    }

    if (body) req.write(body);
    req.end();
  });
}

/**
 * Kirim request JSON dengan timeout dan retry terbatas (429/5xx/error jaringan).
 * @param {object} opts {url, method, headers, body, timeoutMs, retries, retryDelayMs, signal, onRetry}
 * @returns {Promise<{status:number, headers:object, json:object|null, text:string}>}
 */
async function requestJson(opts) {
  const o = Object.assign(
    { method: 'GET', headers: {}, body: null, timeoutMs: 120000, retries: 2, retryDelayMs: 2000, signal: null, onRetry: null },
    opts
  );

  let bodyBuf = null;
  if (o.body !== null && o.body !== undefined) {
    bodyBuf = typeof o.body === 'string' ? Buffer.from(o.body, 'utf8') : Buffer.from(JSON.stringify(o.body), 'utf8');
  }

  let lastError = null;
  for (let attempt = 0; attempt <= o.retries; attempt++) {
    if (o.signal && o.signal.aborted) throw new Error('Dibatalkan oleh pengguna');
    try {
      const res = await rawRequest({
        url: o.url,
        method: o.method,
        headers: o.headers,
        body: bodyBuf,
        timeoutMs: o.timeoutMs,
        signal: o.signal,
      });

      const retryableStatus = res.status === 429 || res.status >= 500;
      if (retryableStatus && attempt < o.retries) {
        const delay = o.retryDelayMs * Math.pow(2, attempt);
        if (o.onRetry) o.onRetry(attempt + 1, res.status, delay);
        await sleep(delay, o.signal);
        continue;
      }

      let json = null;
      try {
        json = res.text ? JSON.parse(res.text) : null;
      } catch (_) {
        json = null; // respons bukan JSON valid
      }
      return { status: res.status, headers: res.headers, json, text: res.text };
    } catch (err) {
      lastError = err;
      if (o.signal && o.signal.aborted) throw err;
      if (String((err && err.message) || '').includes('Dibatalkan')) throw err;
      const netRetry = RETRYABLE_NET.test(String((err && err.message) || ''));
      if (netRetry && attempt < o.retries) {
        const delay = o.retryDelayMs * Math.pow(2, attempt);
        if (o.onRetry) o.onRetry(attempt + 1, 0, delay);
        await sleep(delay, o.signal);
        continue;
      }
      throw err;
    }
  }
  throw lastError || new Error('Request gagal');
}

module.exports = { requestJson, rawRequest, sleep };

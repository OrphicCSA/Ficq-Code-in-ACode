'use strict';

/**
 * Agent Core: loop "berpikir -> panggil tool -> proses hasil -> jawab".
 * Dengan batas iterasi, penggunaan token, dan persetujuan pengguna
 * untuk setiap tool yang membutuhkannya.
 */

const { compactIfNeeded } = require('./context');

const SYSTEM_PROMPT = [
  'Kamu adalah FICQ Agent, asisten pemrogram pribadi yang berjalan di terminal (Acode, Android).',
  'Kamu bekerja di dalam workspace proyek pengguna dan memiliki sekumpulan tool.',
  '',
  'ATURAN KERJA:',
  '1. Untuk segala hal yang berkaitan dengan file atau perintah, GUNAKAN TOOL - jangan menebak isi file.',
  '2. Sebelum mengedit file, baca dulu bagian yang relevan (read_file), lalu edit dengan edit_file menggunakan old_text yang persis dan cukup unik.',
  '3. Untuk membuat file baru gunakan write_file dengan konten lengkap.',
  '4. run_command dijalankan hanya setelah pengguna menyetujui. Jelaskan dengan singkat apa yang dilakukan perintah saat memintanya.',
  '5. Kerjakan tugas bertahap: pahami -> rencanakan -> eksekusi -> laporkan hasilnya.',
  '6. Jangan pernah meminta, menampilkan, atau menyisipkan API key / kredensial ke dalam jawaban atau file.',
  '7. Jangan membaca file rahasia (.env, private key). Tool akan menolak secara otomatis.',
  '8. Jawab dengan bahasa yang sama dengan pengguna (umumnya Bahasa Indonesia), ringkas dan terstruktur.',
  '9. Jika sebuah tool ditolak pengguna atau gagal, sesuaikan pendekatan - jangan mengulang hal yang sama.',
  '10. Setelah menyelesaikan tugas multi-langkah, ringkas apa yang sudah dilakukan dan langkah lanjutan yang disarankan.',
].join('\n');

class AgentCore {
  constructor({ provider, registry, memory, config, ui }) {
    this.provider = provider;
    this.registry = registry;
    this.memory = memory;
    this.config = config;
    this.ui = ui;
    this.approver = null; // di-set oleh CLI
    this.busy = false;
  }

  setApprover(fn) {
    this.approver = fn;
  }

  /**
   * Jalankan satu instruksi pengguna hingga jawaban akhir.
   * @param {string} userText
   * @param {AbortSignal} [signal]
   * @returns {Promise<string>} jawaban akhir model
   */
  async submit(userText, signal) {
    if (this.busy) throw new Error('Agent sedang mengerjakan tugas lain');
    this.busy = true;
    try {
      this.memory.appendText('user', userText);
      const maxIter = this.config.get('maxIterations') || 15;

      for (let iter = 1; iter <= maxIter; iter++) {
        await compactIfNeeded({ memory: this.memory, provider: this.provider, config: this.config, signal, ui: this.ui });

        this.ui.progress('berpikir... (langkah ' + iter + '/' + maxIter + ')');
        let resp;
        try {
          resp = await this.provider.generate({
            system: SYSTEM_PROMPT,
            history: this.memory.entries(),
            toolDecls: this.registry.declarations(),
            signal,
            onRetry: (n, status, delay) => {
              this.ui.warn('retry ke-' + n + ' (status ' + (status || 'jaringan') + '), menunggu ' + Math.round(delay / 1000) + 's...');
            },
          });
        } catch (e) {
          if (signal && signal.aborted) throw new Error('Dibatalkan oleh pengguna');
          throw new Error('Gagal memanggil API: ' + ((e && e.message) || e));
        }

        this.memory.addUsage(resp.usage);

        if (resp.functionCalls && resp.functionCalls.length) {
          this.memory.appendCalls(resp.functionCalls);
          for (const fc of resp.functionCalls) {
            if (signal && signal.aborted) throw new Error('Dibatalkan oleh pengguna');
            await this._runTool(fc, signal);
          }
          continue; // kirim hasil tool kembali ke model
        }

        this.memory.appendText('model', resp.text || '');
        return resp.text || '(model tidak mengembalikan jawaban teks)';
      }

      throw new Error(
        'Batas iterasi agent (' + maxIter + ') tercapai tanpa jawaban akhir. ' +
          'Pecah tugas menjadi langkah yang lebih kecil, atau naikkan maxIterations di konfigurasi.'
      );
    } finally {
      this.busy = false;
      this.ui.progressEnd();
    }
  }

  async _runTool(fc, signal) {
    const name = fc.name;
    const args = fc.args || {};
    const tool = this.registry.get(name);

    if (!tool) {
      this.ui.toolDone(name, false, 'tool tidak dikenal');
      this.memory.appendToolResult(name, { ok: false, error: 'Tool tidak dikenal: ' + name });
      return;
    }

    const v = this.registry.validate(name, args);
    if (!v.ok) {
      this.ui.toolDone(name, false, v.error);
      this.memory.appendToolResult(name, { ok: false, error: v.error });
      return;
    }

    // Persetujuan pengguna untuk tool yang membutuhkan
    if (tool.needsApproval) {
      const desc = tool.describe ? tool.describe(args) : name;
      let ok = false;
      if (this.approver) {
        ok = await this.approver({
          name,
          args,
          describe: desc,
          highRisk: tool.highRisk ? Boolean(tool.highRisk(args)) : false,
        });
      }
      if (!ok) {
        this.ui.toolDone(name, false, 'ditolak pengguna');
        this.memory.appendToolResult(name, {
          ok: false,
          error: 'Pengguna MENOLAK eksekusi tool ini. Lanjutkan tanpa tool tersebut atau tanyakan langkah lain.',
        });
        return;
      }
    }

    this.ui.toolStart(name, tool.describe ? tool.describe(args) : name);
    const { result } = await this.registry.execute(name, args, {
      workspace: process.cwd(),
      config: this.config,
      maxToolOutputChars: this.config.get('maxToolOutputChars'),
    });
    this.memory.toolExecuted();

    // Batas ukuran hasil yang dikirim ke LLM
    const maxChars = this.config.get('maxToolOutputChars') || 8000;
    let llmResult = result;
    const s = JSON.stringify(result);
    if (s && s.length > maxChars) {
      llmResult = { ok: Boolean(result.ok), truncated: true, data: s.slice(0, maxChars) };
    }
    this.memory.appendToolResult(name, llmResult);
    this.ui.toolDone(name, Boolean(result.ok));
  }
}

module.exports = { AgentCore, SYSTEM_PROMPT };

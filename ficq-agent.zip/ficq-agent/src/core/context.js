'use strict';

/**
 * Manajemen konteks: estimasi token dan pemadatan (compaction) riwayat
 * percakapan panjang dengan ringkasan otomatis via LLM.
 */

function estimateHistoryTokens(entries) {
  let chars = 0;
  for (const e of entries || []) {
    if (e.type === 'text') chars += (e.text || '').length;
    else if (e.type === 'calls') chars += JSON.stringify(e.calls || []).length;
    else if (e.type === 'tool') chars += JSON.stringify(e.response || {}).length;
    else if (e.type === 'summary') chars += (e.text || '').length;
    chars += 24; // overhead per entry
  }
  return Math.ceil(chars / 4);
}

const SUMMARIZE_SYSTEM =
  'Kamu meringkas percakapan antara pengguna dan sebuah AI agent pemrogram. ' +
  'Buat ringkasan PADAT (maksimal 250 kata) dalam bahasa yang sama dengan percakapan, mencakup: ' +
  'tujuan pengguna, keputusan penting, file yang dibuat/diubah, perintah yang dijalankan, ' +
  'dan pekerjaan yang belum selesai. Tanpa basa-basi.';

/**
 * Jika estimasi token riwayat melebihi budget, ringkas bagian lama menjadi
 * satu entri 'summary' dan simpan beberapa giliran terbaru apa adanya.
 * Gagal meringkas -> fallback: buang bagian lama (dengan catatan).
 */
async function compactIfNeeded({ memory, provider, config, signal, ui }) {
  const budget = config.get('contextTokenBudget') || 6000;
  const entries = memory.entries();
  const est = estimateHistoryTokens(entries);
  if (est <= budget || entries.length <= 2) return { compacted: false, est };

  const keep = Math.min(6, entries.length - 1);
  const older = entries.slice(0, entries.length - keep);
  const recent = entries.slice(entries.length - keep);
  if (!older.length) return { compacted: false, est };

  const transcript = older
    .map((e) => {
      if (e.type === 'text') return (e.role === 'user' ? 'Pengguna: ' : 'AI: ') + String(e.text || '').slice(0, 4000);
      if (e.type === 'calls') {
        return (
          'AI memanggil tool: ' +
          (e.calls || []).map((c) => c.name + '(' + JSON.stringify(c.args || {}).slice(0, 200) + ')').join('; ')
        );
      }
      if (e.type === 'tool') return 'Hasil tool ' + e.name + ': ' + JSON.stringify(e.response || {}).slice(0, 300);
      if (e.type === 'summary') return 'Ringkasan sebelumnya: ' + String(e.text || '').slice(0, 800);
      return '';
    })
    .filter(Boolean)
    .join('\n')
    .slice(0, 20000);

  if (ui) ui.progress('meringkas konteks panjang...');
  try {
    const resp = await provider.generate({
      system: SUMMARIZE_SYSTEM,
      history: [{ type: 'text', role: 'user', text: transcript }],
      toolDecls: null,
      signal,
    });
    if (resp && resp.text) {
      memory.replaceEntries([{ type: 'summary', text: resp.text, ts: Date.now() }, ...recent]);
      return { compacted: true, fallback: false };
    }
  } catch (_) {
    /* jatuh ke fallback di bawah */
  }
  memory.replaceEntries([
    { type: 'summary', text: '(ringkasan otomatis gagal; sebagian riwayat lama dibuang agar konteks tetap muat)', ts: Date.now() },
    ...recent,
  ]);
  return { compacted: true, fallback: true };
}

module.exports = { estimateHistoryTokens, compactIfNeeded, SUMMARIZE_SYSTEM };

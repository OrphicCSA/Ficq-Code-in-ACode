'use strict';

/**
 * Manajemen konfigurasi FICQ Agent.
 *
 * Lapisan konfigurasi (prioritas menurun):
 *   1. Environment variable  (GEMINI_API_KEY, GEMINI_MODEL, GEMINI_BASE_URL, FICQ_*)
 *   2. ~/.ficq/config.json   (konfigurasi pengguna, non-rahasia)
 *   3. <proyek>/config/default.json (default yang bisa diedit)
 *   4. DEFAULTS di bawah (fallback bawaan kode)
 *
 * API key TIDAK PERNAH disimpan di file konfigurasi ini.
 * Key disimpan terpisah di ~/.ficq/secret (chmod 600) atau env var.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');

const DEFAULTS = {
  provider: 'gemini',
  model: 'gemini-4-hydrogen',
  baseUrl: 'https://generativelanguage.googleapis.com',
  maxIterations: 15,
  requestTimeoutMs: 120000,
  maxRetries: 2,
  retryDelayMs: 2000,
  maxOutputTokens: 4096,
  temperature: 0.4,
  maxToolOutputChars: 8000,
  commandTimeoutMs: 60000,
  contextTokenBudget: 6000,
  checkConnectionOnStart: true,
  maxFileSizeBytes: 262144,
  language: 'id',
};

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(base, extra) {
  const out = Object.assign({}, base);
  if (!isPlainObject(extra)) return out;
  for (const k of Object.keys(extra)) {
    if (isPlainObject(extra[k]) && isPlainObject(out[k])) out[k] = deepMerge(out[k], extra[k]);
    else if (extra[k] !== undefined) out[k] = extra[k];
  }
  return out;
}

function maskKey(key) {
  if (!key || typeof key !== 'string') return '(tidak ada)';
  const t = key.trim();
  if (t.length <= 8) return t.slice(0, 2) + '****';
  return t.slice(0, 6) + '…' + t.slice(-4) + ' (tersembunyi)';
}

/** Hapus pola API key / token dari teks sebelum ditampilkan atau dicatat. */
function redact(text) {
  if (text === null || text === undefined) return text;
  return String(text)
    .replace(/AIza[0-9A-Za-z_-]{6,}/g, 'AIza***REDACTED***')
    .replace(/Bearer\s+[A-Za-z0-9._-]+/gi, 'Bearer ***REDACTED***')
    .replace(/(api[_-]?key\s*[:=]\s*)\S+/gi, '$1***REDACTED***');
}

class Config {
  constructor({ projectRoot = process.cwd(), env = process.env } = {}) {
    this.projectRoot = projectRoot;
    this.env = env;
    this.configDir = env.FICQ_CONFIG_DIR || path.join(os.homedir(), '.ficq');
    this.values = deepMerge(DEFAULTS, this._loadDefaultsFile());
    this.values = deepMerge(this.values, this._loadUserConfig());
    this.values = deepMerge(this.values, this._loadEnvOverrides());
    this._validate();
  }

  _loadDefaultsFile() {
    const p = path.join(this.projectRoot, 'config', 'default.json');
    try {
      if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch (e) {
      process.stderr.write('[ficq] Peringatan: config/default.json tidak valid: ' + e.message + '\n');
    }
    return {};
  }

  _loadUserConfig() {
    const p = path.join(this.configDir, 'config.json');
    try {
      if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch (e) {
      process.stderr.write('[ficq] Peringatan: ~/.ficq/config.json tidak valid: ' + e.message + '\n');
    }
    return {};
  }

  _loadEnvOverrides() {
    const o = {};
    if (this.env.GEMINI_MODEL) o.model = this.env.GEMINI_MODEL;
    if (this.env.GEMINI_BASE_URL) o.baseUrl = this.env.GEMINI_BASE_URL;
    if (this.env.FICQ_PROVIDER) o.provider = this.env.FICQ_PROVIDER;
    return o;
  }

  _validate() {
    const v = this.values;
    if (!Number.isFinite(v.maxIterations) || v.maxIterations < 1 || v.maxIterations > 60) {
      v.maxIterations = DEFAULTS.maxIterations;
    }
    if (!Number.isFinite(v.requestTimeoutMs) || v.requestTimeoutMs < 5000) {
      v.requestTimeoutMs = DEFAULTS.requestTimeoutMs;
    }
    if (typeof v.model !== 'string' || !v.model.trim()) v.model = DEFAULTS.model;
    if (typeof v.baseUrl !== 'string' || !/^https?:\/\//.test(v.baseUrl)) v.baseUrl = DEFAULTS.baseUrl;
  }

  get(key) {
    return this.values[key];
  }

  all() {
    return Object.assign({}, this.values);
  }

  /** Ubah + simpan ke konfigurasi pengguna (~/.ficq/config.json). */
  setPersist(key, value) {
    this.values[key] = value;
    const p = path.join(this.configDir, 'config.json');
    fs.mkdirSync(this.configDir, { recursive: true, mode: 0o700 });
    let current = {};
    try {
      if (fs.existsSync(p)) current = JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch (_) {
      current = {};
    }
    current[key] = value;
    fs.writeFileSync(p, JSON.stringify(current, null, 2) + '\n', { mode: 0o600 });
    try {
      fs.chmodSync(p, 0o600);
    } catch (_) { /* beberapa filesystem Android tidak mendukung chmod */ }
    return p;
  }

  get secretPath() {
    return path.join(this.configDir, 'secret');
  }

  /**
   * Ambil API key dari env var atau file secret. TIDAK PERNAH dicetak / dicatat.
   * @returns {{key: string|null, source: 'env'|'file'|null, warnings: string[]}}
   */
  resolveApiKey() {
    const warnings = [];
    const envKey = this.env.GEMINI_API_KEY;
    if (envKey && envKey.trim()) {
      return { key: envKey.trim(), source: 'env', warnings };
    }
    try {
      if (fs.existsSync(this.secretPath)) {
        const st = fs.statSync(this.secretPath);
        const perm = st.mode & 0o777;
        if (perm & 0o077) {
          warnings.push(
            'File secret (~/.ficq/secret) permission-nya ' +
              perm.toString(8) +
              ' (seharusnya 600). Jalankan: chmod 600 ' +
              this.secretPath
          );
          try {
            fs.chmodSync(this.secretPath, 0o600);
          } catch (_) { /* abaikan; filesystem mungkin tidak mendukung */ }
        }
        const key = fs.readFileSync(this.secretPath, 'utf8').trim();
        if (key) return { key, source: 'file', warnings };
      }
    } catch (e) {
      warnings.push('Gagal membaca file secret: ' + e.message);
    }
    return { key: null, source: null, warnings };
  }

  /** Simpan API key ke file terpisah dengan permission ketat. */
  saveApiKey(key) {
    fs.mkdirSync(this.configDir, { recursive: true, mode: 0o700 });
    fs.writeFileSync(this.secretPath, key.trim() + '\n', { mode: 0o600 });
    try {
      fs.chmodSync(this.secretPath, 0o600);
      fs.chmodSync(this.configDir, 0o700);
    } catch (_) { /* filesystem Android tertentu tidak mendukung chmod */ }
    return this.secretPath;
  }
}

module.exports = { Config, DEFAULTS, maskKey, redact, deepMerge };

'use strict';

/**
 * Memori sesi: riwayat percakapan, penggunaan token, dan persistensi lokal.
 * API key TIDAK PERNAH disimpan di sini (key tidak pernah masuk konteks model).
 */

const fs = require('fs');
const path = require('path');

class Session {
  constructor(data) {
    this.data = data || {
      version: 1,
      id: null,
      createdAt: null,
      updatedAt: null,
      model: null,
      provider: null,
      workspace: null,
      usage: { apiRequests: 0, promptTokens: 0, completionTokens: 0, totalTokens: 0, toolExecutions: 0 },
      entries: [],
    };
    if (!this.data.id) {
      this.data.id =
        new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19) +
        '-' +
        Math.random().toString(36).slice(2, 6);
      this.data.createdAt = Date.now();
    }
    if (!this.data.usage) {
      this.data.usage = { apiRequests: 0, promptTokens: 0, completionTokens: 0, totalTokens: 0, toolExecutions: 0 };
    }
  }

  get id() {
    return this.data.id;
  }

  get usage() {
    return this.data.usage;
  }

  entries() {
    return this.data.entries;
  }

  setModel(m) {
    this.data.model = m;
  }

  appendText(role, text) {
    this.data.entries.push({ type: 'text', role, text: String(text || ''), ts: Date.now() });
    this.touch();
  }

  appendCalls(calls) {
    this.data.entries.push({
      type: 'calls',
      role: 'model',
      calls: (calls || []).map((c) => ({ name: c.name, args: c.args || {} })),
      ts: Date.now(),
    });
    this.touch();
  }

  appendToolResult(name, response) {
    this.data.entries.push({ type: 'tool', name, response, ts: Date.now() });
    this.touch();
  }

  replaceEntries(entries) {
    this.data.entries = entries;
    this.touch();
  }

  addUsage(u) {
    const s = this.data.usage;
    s.apiRequests += 1;
    s.promptTokens += u && u.input ? u.input : 0;
    s.completionTokens += u && u.output ? u.output : 0;
    s.totalTokens += u && u.total ? u.total : 0;
    this.touch();
  }

  toolExecuted() {
    this.data.usage.toolExecutions += 1;
  }

  touch() {
    this.data.updatedAt = Date.now();
  }
}

class SessionStore {
  constructor({ dir }) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
  }

  fileOf(id) {
    return path.join(this.dir, 'sesi-' + id + '.json');
  }

  create(opts) {
    const s = new Session(null);
    Object.assign(s.data, opts || {});
    this.save(s);
    return s;
  }

  save(s) {
    const f = this.fileOf(s.data.id);
    const tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(s.data));
    fs.renameSync(tmp, f);
    return f;
  }

  list() {
    const out = [];
    let files = [];
    try {
      files = fs.readdirSync(this.dir).filter((f) => f.startsWith('sesi-') && f.endsWith('.json'));
    } catch (_) {
      return out;
    }
    for (const f of files) {
      try {
        const d = JSON.parse(fs.readFileSync(path.join(this.dir, f), 'utf8'));
        const firstUser = (d.entries || []).find((e) => e.type === 'text' && e.role === 'user');
        out.push({
          id: d.id,
          createdAt: d.createdAt,
          updatedAt: d.updatedAt,
          model: d.model,
          entries: (d.entries || []).length,
          totalTokens: d.usage ? d.usage.totalTokens : 0,
          preview: firstUser ? String(firstUser.text || '').slice(0, 60) : '(kosong)',
        });
      } catch (_) {
        /* lewati file rusak */
      }
    }
    out.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    return out;
  }

  load(id) {
    const f = this.fileOf(id);
    if (!fs.existsSync(f)) return null;
    try {
      const d = JSON.parse(fs.readFileSync(f, 'utf8'));
      return new Session(d);
    } catch (e) {
      return null;
    }
  }

  latest() {
    const l = this.list();
    return l.length ? this.load(l[0].id) : null;
  }
}

module.exports = { Session, SessionStore };

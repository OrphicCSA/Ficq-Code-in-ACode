'use strict';

/**
 * Tools terminal: run_command (dengan approval + scrubbing env) dan
 * get_environment (informasi lingkungan runtime).
 */

const { spawn } = require('child_process');
const os = require('os');
const { classifyCommand, explainCommand } = require('./safety');

const MAX_STREAM_BYTES = 64 * 1024; // batas stdout/stderr per stream

/** Hapus variabel environment berpotensi rahasia sebelum diteruskan ke child process. */
function scrubbedEnv() {
  const env = {};
  for (const k of Object.keys(process.env)) {
    if (/API_KEY|_TOKEN|_SECRET|PASSWORD|GEMINI|FICQ/i.test(k)) continue;
    env[k] = process.env[k];
  }
  env.FICQ_SANDBOX = '1';
  return env;
}

/** Jalankan perintah shell dengan batas waktu + batas output. */
function runShell(command, { cwd, timeoutMs }) {
  return new Promise((resolve) => {
    let stdout = '';
    let stderr = '';
    let stdoutTruncated = 0;
    let stderrTruncated = 0;
    let timedOut = false;
    const started = Date.now();

    let child;
    try {
      child = spawn(command, {
        shell: true,
        cwd,
        env: scrubbedEnv(),
        timeout: timeoutMs,
        killSignal: 'SIGKILL',
      });
    } catch (e) {
      return resolve({ ok: false, exitCode: -1, stdout: '', stderr: 'spawn gagal: ' + e.message, timedOut: false, durationMs: 0 });
    }

    child.stdout.on('data', (d) => {
      if (stdout.length < MAX_STREAM_BYTES) stdout += d.toString('utf8');
      else stdoutTruncated += d.length;
    });
    child.stderr.on('data', (d) => {
      if (stderr.length < MAX_STREAM_BYTES) stderr += d.toString('utf8');
      else stderrTruncated += d.length;
    });

    const timer = setTimeout(() => {
      timedOut = true;
      try {
        child.kill('SIGKILL');
      } catch (_) { /* sudah mati */ }
    }, timeoutMs);

    child.on('error', (e) => {
      clearTimeout(timer);
      resolve({ ok: false, exitCode: -1, stdout, stderr: stderr + '\n' + e.message, timedOut, durationMs: Date.now() - started });
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      if (stdoutTruncated) stdout += '\n...[stdout dipotong ' + stdoutTruncated + ' byte]';
      if (stderrTruncated) stderr += '\n...[stderr dipotong ' + stderrTruncated + ' byte]';
      resolve({ ok: code === 0 && !timedOut, exitCode: code, stdout, stderr, timedOut, durationMs: Date.now() - started });
    });
  });
}

function defineTerminalTools(registry, config) {
  // ---------------------------------------------------------------- run_command
  registry.register({
    name: 'run_command',
    description:
      'Menjalankan perintah shell di workspace SETELAH pengguna menyetujui. Perintah berisiko (hapus, install, jaringan) butuh konfirmasi tambahan.',
    parameters: {
      type: 'object',
      properties: {
        command: { type: 'string', description: 'Perintah shell yang akan dijalankan' },
        timeout_sec: { type: 'integer', description: 'Batas waktu eksekusi detik (default dari config, maks 600)' },
      },
      required: ['command'],
    },
    needsApproval: true,
    highRisk: (a) => classifyCommand(a.command).risk === 'high',
    describe: (a) => {
      const ex = explainCommand(a.command);
      return '$ ' + a.command + '  [' + ex.label + (ex.reasons.length ? ': ' + ex.reasons.join(', ') : '') + ']';
    },
    async execute(args) {
      if (!String(args.command || '').trim()) return { ok: false, error: 'Perintah kosong' };
      const timeoutSec = Math.min(args.timeout_sec || 0, 600);
      const timeoutMs = (timeoutSec > 0 ? timeoutSec * 1000 : config.get('commandTimeoutMs')) || 60000;
      const r = await runShell(args.command, { cwd: process.cwd(), timeoutMs });
      return {
        ok: r.ok,
        data: {
          exitCode: r.exitCode,
          timedOut: r.timedOut,
          durationMs: r.durationMs,
          stdout: r.stdout || '(kosong)',
          stderr: r.stderr || '(kosong)',
        },
      };
    },
  });

  // ---------------------------------------------------------------- get_environment
  registry.register({
    name: 'get_environment',
    description: 'Memeriksa informasi lingkungan runtime: OS, arsitektur, versi Node.js, RAM, CPU, direktori kerja.',
    parameters: { type: 'object', properties: {}, required: [] },
    needsApproval: false,
    describe: () => 'memeriksa informasi lingkungan',
    async execute() {
      const total = os.totalmem();
      const free = os.freemem();
      return {
        ok: true,
        data: {
          platform: os.platform(),
          arch: os.arch(),
          nodeVersion: process.version,
          cpuCount: os.cpus().length,
          cpuModel: os.cpus()[0] ? os.cpus()[0].model.split(':').pop().trim().slice(0, 60) : 'tidak diketahui',
          totalMemMB: Math.round(total / 1024 / 1024),
          freeMemMB: Math.round(free / 1024 / 1024),
          memUsagePercent: Math.round(((total - free) / total) * 100),
          uptimeHours: Math.round(os.uptime() / 3600),
          cwd: process.cwd(),
          tmpDir: os.tmpdir(),
          isTTY: Boolean(process.stdout.isTTY),
        },
      };
    },
  });
}

module.exports = { defineTerminalTools, runShell, scrubbedEnv };

'use strict';

/**
 * Registry tools: registrasi, validasi argumen berbasis schema,
 * eksekusi terstandardisasi, dan pembatasan ukuran output.
 */

const MAX_SCHEMA_DEPTH = 4;

/** Konversi schema JSON-ish internal ke format Gemini (tipe UPPERCASE, properti dibersihkan). */
function normalizeSchema(schema, depth = 0) {
  if (!schema || typeof schema !== 'object' || depth > MAX_SCHEMA_DEPTH) {
    return { type: 'STRING' };
  }
  const out = {};
  const t = String(schema.type || 'string').toLowerCase();
  const typeMap = {
    string: 'STRING', number: 'NUMBER', integer: 'INTEGER',
    boolean: 'BOOLEAN', array: 'ARRAY', object: 'OBJECT',
  };
  out.type = typeMap[t] || 'STRING';
  if (schema.description) out.description = String(schema.description).slice(0, 500);
  if (schema.enum) out.enum = schema.enum.map((v) => String(v));
  if (out.type === 'ARRAY' && schema.items) out.items = normalizeSchema(schema.items, depth + 1);
  if (out.type === 'OBJECT' && schema.properties) {
    out.properties = {};
    for (const k of Object.keys(schema.properties)) {
      out.properties[k] = normalizeSchema(schema.properties[k], depth + 1);
    }
    if (Array.isArray(schema.required) && schema.required.length) {
      out.required = schema.required.map(String);
    }
  }
  return out;
}

const TYPE_CHECK = {
  string: (v) => typeof v === 'string',
  number: (v) => typeof v === 'number' && Number.isFinite(v),
  integer: (v) => typeof v === 'number' && Number.isInteger(v),
  boolean: (v) => typeof v === 'boolean',
  array: (v) => Array.isArray(v),
  object: (v) => v !== null && typeof v === 'object' && !Array.isArray(v),
};

class ToolRegistry {
  constructor() {
    this._tools = new Map();
  }

  register(def) {
    if (!def || typeof def.name !== 'string' || !/^[a-z][a-z0-9_]{2,40}$/.test(def.name)) {
      throw new Error('Nama tool tidak valid (harus snake_case 3-41 karakter): ' + (def && def.name));
    }
    if (typeof def.execute !== 'function') throw new Error('Tool ' + def.name + ' tidak punya execute()');
    if (typeof def.description !== 'string' || !def.description) {
      throw new Error('Tool ' + def.name + ' tidak punya deskripsi');
    }
    this._tools.set(def.name, def);
  }

  get(name) {
    return this._tools.get(name) || null;
  }

  has(name) {
    return this._tools.has(name);
  }

  names() {
    return Array.from(this._tools.keys());
  }

  list() {
    return Array.from(this._tools.values());
  }

  /** Deklarasi tools untuk dikirim ke LLM. */
  declarations() {
    return this.list().map((t) => ({
      name: t.name,
      description: t.description,
      parameters: normalizeSchema(t.parameters || { type: 'object', properties: {} }),
    }));
  }

  /** Validasi argumen terhadap schema. @returns {{ok:boolean, args?:object, error?:string}} */
  validate(name, args) {
    const t = this._tools.get(name);
    if (!t) return { ok: false, error: 'Tool tidak dikenal: ' + name };
    if (args === undefined || args === null) args = {};
    if (typeof args !== 'object' || Array.isArray(args)) {
      return { ok: false, error: 'Argumen harus berupa object' };
    }
    const params = t.parameters || { type: 'object', properties: {} };
    const props = params.properties || {};
    const required = params.required || [];

    for (const r of required) {
      if (args[r] === undefined || args[r] === null) {
        return { ok: false, error: "Parameter '" + r + "' wajib diisi" };
      }
    }
    for (const k of Object.keys(args)) {
      if (!Object.prototype.hasOwnProperty.call(props, k)) {
        return { ok: false, error: "Parameter tidak dikenal: '" + k + "'" };
      }
      const expected = String(props[k].type || 'string').toLowerCase();
      const check = TYPE_CHECK[expected];
      if (check && !check(args[k])) {
        return { ok: false, error: "Parameter '" + k + "' harus bertipe " + expected };
      }
      if (typeof args[k] === 'string' && args[k].length > 200000) {
        return { ok: false, error: "Parameter '" + k + "' terlalu panjang (maks 200000 karakter)" };
      }
    }
    return { ok: true, args };
  }

  /**
   * Eksekusi tool dengan validasi + normalisasi hasil.
   * Batas ukuran output ke LLM diterapkan di Agent Core.
   * @returns {Promise<{ok:boolean, result:object}>}
   */
  async execute(name, args, ctx) {
    const v = this.validate(name, args);
    if (!v.ok) return { ok: false, result: { ok: false, error: v.error } };

    const t = this._tools.get(name);
    const started = Date.now();
    try {
      let result = await t.execute(v.args, ctx);
      if (result === undefined || result === null) result = { ok: true, data: '(kosong)' };
      if (typeof result !== 'object' || Array.isArray(result)) result = { ok: true, data: result };
      if (result.ok === undefined) result.ok = true;
      result.durationMs = Date.now() - started;
      return { ok: !!result.ok, result };
    } catch (e) {
      const msg = (e && e.message) || String(e);
      return { ok: false, result: { ok: false, error: msg, durationMs: Date.now() - started } };
    }
  }
}

module.exports = { ToolRegistry, normalizeSchema };

'use strict';

/**
 * Tools proyek: analyze_project, run_tests, git_status.
 */

const fs = require('fs');
const path = require('path');
const { walkTree } = require('./filesystem');
const { runShell } = require('./terminal');

const SKIP_DIRS = new Set(['node_modules', '.git', '.cache', 'dist', 'build', '__pycache__', 'data']);

const MANIFESTS = [
  'package.json', 'pyproject.toml', 'requirements.txt', 'setup.py', 'go.mod', 'Cargo.toml',
  'composer.json', 'Gemfile', 'pom.xml', 'build.gradle', 'Makefile', 'CMakeLists.txt',
  'index.html', 'tsconfig.json', 'Dockerfile', '.gitignore',
];

function readJsonSafe(p) {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (_) {
    return null;
  }
}

function defineProjectTools(registry, config) {
  // ---------------------------------------------------------------- analyze_project
  registry.register({
    name: 'analyze_project',
    description: 'Menganalisis struktur dan teknologi proyek: bahasa, manifest, framework, jumlah file, titik masuk.',
    parameters: { type: 'object', properties: {}, required: [] },
    needsApproval: false,
    describe: () => 'menganalisis struktur proyek',
    async execute() {
      const root = process.cwd();
      const extCount = {};
      let fileCount = 0;
      walkTree(root, { skip: SKIP_DIRS, maxEntries: 5000 }, (file) => {
        fileCount++;
        const ext = path.extname(file).slice(1).toLowerCase() || '(tanpa ekstensi)';
        extCount[ext] = (extCount[ext] || 0) + 1;
        return true;
      });

      const manifests = {};
      for (const m of MANIFESTS) {
        const p = path.join(root, m);
        if (fs.existsSync(p)) manifests[m] = p;
      }

      let pkg = null;
      if (manifests['package.json']) pkg = readJsonSafe(manifests['package.json']);

      const frameworks = [];
      if (pkg) {
        const deps = Object.assign({}, pkg.dependencies, pkg.devDependencies);
        const known = {
          react: 'React', vue: 'Vue', svelte: 'Svelte', express: 'Express', next: 'Next.js',
          nuxt: 'Nuxt', astro: 'Astro', typescript: 'TypeScript', tailwindcss: 'Tailwind CSS',
          jest: 'Jest', vitest: 'Vitest', mocha: 'Mocha', playwright: 'Playwright',
        };
        for (const k of Object.keys(known)) if (deps && deps[k]) frameworks.push(known[k]);
      }
      if (manifests['requirements.txt'] || manifests['pyproject.toml']) frameworks.push('Python');
      if (manifests['go.mod']) frameworks.push('Go');
      if (manifests['Cargo.toml']) frameworks.push('Rust');

      const topExt = Object.entries(extCount)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 8)
        .map(([ext, n]) => ({ ext, files: n }));

      return {
        ok: true,
        data: {
          workspace: root,
          fileCount,
          languages: topExt,
          manifests: Object.keys(manifests),
          frameworks,
          package: pkg ? { name: pkg.name, version: pkg.version, scripts: Object.keys(pkg.scripts || {}) } : null,
        },
      };
    },
  });

  // ---------------------------------------------------------------- run_tests
  registry.register({
    name: 'run_tests',
    description: 'Menjalankan pengujian proyek (deteksi otomatis npm test / pytest / make test, atau perintah kustom). Butuh persetujuan.',
    parameters: {
      type: 'object',
      properties: {
        test_command: { type: 'string', description: 'Perintah test kustom (opsional; default deteksi otomatis)' },
      },
      required: [],
    },
    needsApproval: true,
    highRisk: () => false,
    describe: (a) => 'menjalankan pengujian' + (a && a.test_command ? ': ' + a.test_command : ' (deteksi otomatis)'),
    async execute(args) {
      let cmd = args.test_command;
      let note = null;
      if (!cmd) {
        const pkg = readJsonSafe(path.join(process.cwd(), 'package.json'));
        if (pkg && pkg.scripts && pkg.scripts.test && pkg.scripts.test !== 'Error: no test specified') {
          cmd = 'npm test';
        } else if (fs.existsSync(path.join(process.cwd(), 'pytest.ini')) || fs.existsSync(path.join(process.cwd(), 'pyproject.toml'))) {
          cmd = 'python3 -m pytest -q';
        } else if (fs.existsSync(path.join(process.cwd(), 'Makefile'))) {
          cmd = 'make test';
        } else {
          return {
            ok: false,
            error: 'Tidak menemukan konfigurasi test. Berikan test_command manual atau buat test terlebih dahulu.',
          };
        }
        note = 'terdeteksi otomatis: ' + cmd;
      }
      const timeoutMs = Math.max(config.get('commandTimeoutMs') || 60000, 180000);
      const r = await runShell(cmd, { cwd: process.cwd(), timeoutMs });
      return {
        ok: r.ok,
        data: { note, command: cmd, exitCode: r.exitCode, timedOut: r.timedOut, durationMs: r.durationMs, stdout: r.stdout || '(kosong)', stderr: r.stderr || '(kosong)' },
      };
    },
  });

  // ---------------------------------------------------------------- git_status
  registry.register({
    name: 'git_status',
    description: 'Memeriksa status Git workspace: branch, file berubah, dan 5 commit terakhir. Baca-saja, tanpa persetujuan.',
    parameters: { type: 'object', properties: {}, required: [] },
    needsApproval: false,
    describe: () => 'memeriksa status Git',
    async execute() {
      const gitDir = path.join(process.cwd(), '.git');
      if (!fs.existsSync(gitDir)) return { ok: false, error: 'Direktori ini bukan repositori Git' };
      const st = await runShell('git status --porcelain=v1 -b && git log --oneline -5 2>/dev/null || true', {
        cwd: process.cwd(),
        timeoutMs: 15000,
      });
      if (!st.ok && !st.stdout) {
        return { ok: false, error: 'git tidak tersedia atau gagal dijalankan: ' + (st.stderr || 'exit ' + st.exitCode) };
      }
      return { ok: true, data: { output: st.stdout || '(workspace bersih)' } };
    },
  });
}

module.exports = { defineProjectTools };

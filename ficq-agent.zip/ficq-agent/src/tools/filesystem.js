'use strict';

/**
 * Tools filesystem: list_files, read_file, write_file, edit_file, search_files.
 * Semua path dipaksa tetap di dalam workspace oleh safety.resolveInWorkspace.
 */

const fs = require('fs');
const path = require('path');
const { resolveInWorkspace, isSensitiveFile, isProtectedDir } = require('./safety');

const SKIP_DIRS = new Set(['node_modules', '.git', '.cache', 'dist', 'build', '__pycache__']);
const SKIP_SEARCH_DIRS = new Set([...SKIP_DIRS, 'data']);

/** Iterasi pohon file secara iteratif (hemat memori untuk pohon dalam). */
function walkTree(root, { skip = SKIP_DIRS, maxEntries = 20000 } = {}, cb) {
  const stack = [root];
  let count = 0;
  while (stack.length && count < maxEntries) {
    const dir = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (_) {
      continue;
    }
    for (const ent of entries) {
      if (count >= maxEntries) break;
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        if (!skip.has(ent.name)) {
          count++;
          stack.push(full);
        }
      } else if (ent.isFile()) {
        count++;
        if (cb(full) === false) return count;
      }
    }
  }
  return count;
}

function statSafe(p) {
  try {
    return fs.statSync(p);
  } catch (_) {
    return null;
  }
}

function looksBinary(buf) {
  const slice = buf.subarray(0, Math.min(buf.length, 4096));
  return slice.includes(0);
}

function defineFilesystemTools(registry, config) {
  // ---------------------------------------------------------------- list_files
  registry.register({
    name: 'list_files',
    description: 'Melihat isi direktori (nama, ukuran, direktori/file). Gunakan path "." untuk root workspace.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Path direktori relatif workspace (default ".")' },
      },
      required: [],
    },
    needsApproval: false,
    describe: (a) => 'menampilkan isi direktori ' + (a && a.path ? a.path : '.'),
    async execute(args) {
      const abs = resolveInWorkspace(process.cwd(), args.path || '.');
      const st = statSafe(abs);
      if (!st) return { ok: false, error: 'Path tidak ditemukan: ' + args.path };
      if (!st.isDirectory()) return { ok: false, error: 'Bukan direktori: ' + args.path };
      const entries = fs.readdirSync(abs, { withFileTypes: true });
      const out = [];
      for (const e of entries.slice(0, 500)) {
        const full = path.join(abs, e.name);
        if (e.isDirectory()) out.push({ name: e.name + '/', type: 'dir' });
        else {
          const s = statSafe(full);
          out.push({ name: e.name, type: 'file', size: s ? s.size : 0 });
        }
      }
      return {
        ok: true,
        data: { path: args.path || '.', total: entries.length, shown: out.length, entries: out },
      };
    },
  });

  // ---------------------------------------------------------------- read_file
  registry.register({
    name: 'read_file',
    description:
      'Membaca isi file teks (kode, config, markdown). Menolak file rahasia seperti .env atau private key. File besar hanya dibaca sebagian.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Path file relatif workspace' },
        offset_line: { type: 'integer', description: 'Baris mulai (1-based, opsional)' },
        max_lines: { type: 'integer', description: 'Maksimum baris yang dibaca (opsional)' },
      },
      required: ['path'],
    },
    needsApproval: false,
    describe: (a) => 'membaca file ' + (a ? a.path : ''),
    async execute(args) {
      const abs = resolveInWorkspace(process.cwd(), args.path);
      if (isSensitiveFile(abs)) {
        return {
          ok: false,
          error:
            'File "' + path.basename(abs) + '" terdeteksi berisi potensi kredensial dan tidak boleh dibaca otomatis oleh agent. ' +
            'Buka manual di editor jika benar-benar diperlukan.',
        };
      }
      const st = statSafe(abs);
      if (!st) return { ok: false, error: 'File tidak ditemukan: ' + args.path };
      if (st.isDirectory()) return { ok: false, error: 'Path adalah direktori, gunakan list_files: ' + args.path };
      const maxBytes = config.get('maxFileSizeBytes') || 262144;
      if (st.size > maxBytes) {
        return { ok: false, error: 'File terlalu besar (' + st.size + ' byte > ' + maxBytes + '). Baca sebagian dengan offset_line/max_lines.' };
      }
      const buf = fs.readFileSync(abs);
      if (looksBinary(buf)) return { ok: false, error: 'File biner - tidak dapat dibaca sebagai teks' };
      const lines = buf.toString('utf8').split('\n');
      const offset = Math.max(1, args.offset_line || 1);
      const maxLines = Math.min(args.max_lines || 400, 1000);
      const slice = lines.slice(offset - 1, offset - 1 + maxLines);
      const totalLines = lines.length;
      const notes = [];
      if (offset > 1) notes.push('mulai dari baris ' + offset);
      if (offset - 1 + slice.length < totalLines) {
        notes.push('SISA ' + (totalLines - (offset - 1 + slice.length)) + ' baris belum dibaca - lanjutkan dengan offset_line');
      }
      return {
        ok: true,
        data: { path: args.path, totalLines, notes: notes.join('; ') || null, content: slice.join('\n') },
      };
    },
  });

  // ---------------------------------------------------------------- write_file
  registry.register({
    name: 'write_file',
    description: 'Membuat file baru atau menimpa file yang ada dengan konten penuh. SELALU butuh persetujuan pengguna.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Path file tujuan relatif workspace' },
        content: { type: 'string', description: 'Konten lengkap file yang akan ditulis' },
      },
      required: ['path', 'content'],
    },
    needsApproval: true,
    describe: (a) => {
      const abs = (() => {
        try {
          return resolveInWorkspace(process.cwd(), a.path);
        } catch (e) {
          return a.path;
        }
      })();
      const exists = fs.existsSync(abs);
      return (exists ? 'menimpa file ' : 'membuat file baru ') + a.path + (exists ? ' (isi lama akan hilang)' : '');
    },
    async execute(args) {
      const abs = resolveInWorkspace(process.cwd(), args.path);
      if (isProtectedDir(abs)) return { ok: false, error: 'Menulis ke dalam .git/ tidak diizinkan' };
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, args.content, 'utf8');
      const s = statSafe(abs);
      return { ok: true, data: { path: args.path, bytesWritten: s ? s.size : Buffer.byteLength(args.content) } };
    },
  });

  // ---------------------------------------------------------------- edit_file
  registry.register({
    name: 'edit_file',
    description:
      'Mengubah bagian tertentu dari file: ganti old_text dengan new_text. old_text harus unik kecuali replace_all=true. SELALU butuh persetujuan pengguna.',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: 'Path file relatif workspace' },
        old_text: { type: 'string', description: 'Teks lama yang akan diganti (harus persis, termasuk indentasi)' },
        new_text: { type: 'string', description: 'Teks pengganti' },
        replace_all: { type: 'boolean', description: 'Ganti semua kemunculan (default false)' },
      },
      required: ['path', 'old_text', 'new_text'],
    },
    needsApproval: true,
    describe: (a) => 'mengedit file ' + a.path + ' (mengganti ' + String(a.old_text).length + ' karakter)',
    async execute(args) {
      const abs = resolveInWorkspace(process.cwd(), args.path);
      if (isProtectedDir(abs)) return { ok: false, error: 'Mengedit file di dalam .git/ tidak diizinkan' };
      const st = statSafe(abs);
      if (!st) return { ok: false, error: 'File tidak ditemukan: ' + args.path + '. Gunakan write_file untuk membuat baru.' };
      const maxBytes = config.get('maxFileSizeBytes') || 262144;
      if (st.size > maxBytes) return { ok: false, error: 'File terlalu besar untuk diedit otomatis (' + st.size + ' byte)' };
      const original = fs.readFileSync(abs, 'utf8');
      const oldText = args.old_text;
      if (!oldText) return { ok: false, error: 'old_text tidak boleh kosong' };
      const count = original.split(oldText).length - 1;
      if (count === 0) {
        return { ok: false, error: 'old_text tidak ditemukan di file. Pastikan teks persis sama (termasuk spasi/indentasi).' };
      }
      if (count > 1 && !args.replace_all) {
        return {
          ok: false,
          error: 'old_text ditemukan ' + count + ' kali (tidak unik). Perluas konteks old_text atau set replace_all=true.',
        };
      }
      const replaced = args.replace_all
        ? original.split(oldText).join(args.new_text)
        : original.replace(oldText, args.new_text);
      fs.writeFileSync(abs, replaced, 'utf8');
      return { ok: true, data: { path: args.path, replacements: args.replace_all ? count : 1 } };
    },
  });

  // ---------------------------------------------------------------- search_files
  registry.register({
    name: 'search_files',
    description: 'Mencari teks atau pola regex di seluruh file proyek. Melewati node_modules dan .git.',
    parameters: {
      type: 'object',
      properties: {
        pattern: { type: 'string', description: 'Teks atau pola regex yang dicari' },
        is_regex: { type: 'boolean', description: 'True jika pattern adalah regex (default false = teks biasa)' },
        max_results: { type: 'integer', description: 'Maksimum hasil (default 50, maks 200)' },
      },
      required: ['pattern'],
    },
    needsApproval: false,
    describe: (a) => 'mencari "' + String(a.pattern).slice(0, 40) + '" di proyek',
    async execute(args) {
      let re;
      try {
        re = args.is_regex ? new RegExp(args.pattern, 'i') : new RegExp(escapeRe(args.pattern), 'i');
      } catch (e) {
        return { ok: false, error: 'Regex tidak valid: ' + e.message };
      }
      const maxResults = Math.min(args.max_results || 50, 200);
      const matches = [];
      let scanned = 0;
      const maxBytes = config.get('maxFileSizeBytes') || 262144;
      walkTree(
        process.cwd(),
        { skip: SKIP_SEARCH_DIRS, maxEntries: 8000 },
        (file) => {
          scanned++;
          if (matches.length >= maxResults) return false;
          const st = statSafe(file);
          if (!st || st.size > maxBytes) return true;
          let content;
          try {
            content = fs.readFileSync(file);
          } catch (_) {
            return true;
          }
          if (looksBinary(content)) return true;
          const lines = content.toString('utf8').split('\n');
          for (let i = 0; i < lines.length; i++) {
            if (re.test(lines[i])) {
              matches.push({
                file: path.relative(process.cwd(), file),
                line: i + 1,
                text: lines[i].trim().slice(0, 200),
              });
              if (matches.length >= maxResults) break;
            }
          }
          return true;
        }
      );
      return { ok: true, data: { pattern: args.pattern, filesScanned: scanned, matchCount: matches.length, matches } };
    },
  });
}

function escapeRe(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

module.exports = { defineFilesystemTools, walkTree };

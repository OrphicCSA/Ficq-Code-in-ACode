'use strict';

/**
 * Lapisan keamanan: penjagaan path workspace, deteksi file rahasia,
 * dan klasifikasi risiko perintah terminal.
 */

const fs = require('fs');
const path = require('path');

const SENSITIVE_FILE_PATTERNS = [
  /^\.env(\..+)?$/i,
  /id_rsa|id_dsa|id_ecdsa|id_ed25519/i,
  /\.pem$|\.key$|\.p12$|\.pfx$/i,
  /^credentials?(\.json)?$/i,
  /^\.netrc$/i,
  /^\.git-credentials$/i,
  /service[-_]?account.*\.json$/i,
  /^secret/i,
  /^\.ficq/i,
];

const HIGH_RISK_PATTERNS = [
  { re: /\brm\b|\brmdir\b|\bshred\b|\bmkfs|\bdd\s+if=/, why: 'menghapus data' },
  { re: /\bchmod\b|\bchown\b|\bchgrp\b/, why: 'mengubah hak akses file' },
  { re: /\bkill\b|\bpkill\b|\bkillall\b|\breboot\b|\bshutdown\b|\bpoweroff\b/, why: 'menghentikan proses / sistem' },
  { re: /\bsudo\b|\bsu\s|\bdoas\b/, why: 'eksekusi dengan hak istimewa' },
  { re: /\b(apk|apt|apt-get|dnf|yum|pacman|pip3?|npm)\s+(install|add|remove|uninstall|purge|upgrade)/, why: 'memasang / menghapus paket' },
  { re: /\bcurl\b|\bwget\b|\bping\b|\bnc\b|\bssh\b|\bscp\b|\brsync\b|\btelnet\b/, why: 'mengakses jaringan' },
  { re: /\bgit\s+(push|reset\s+--hard|clean|filter-branch)\b/, why: 'mengubah repositori secara destruktif' },
  { re: />\s*\/(dev|etc|usr|bin|sbin|boot)\//, why: 'menulis ke direktori sistem' },
  { re: /\bdrop\s+(table|database)\b/i, why: 'menghapus database' },
  { re: /\benv\b|\bprintenv\b|\bset\b/, why: 'menampilkan environment (bisa membocorkan rahasia)' },
];

const MEDIUM_RISK_PATTERNS = [
  { re: /\bmkdir\b|\btouch\b|\bcp\b|\bmv\b|\btee\b|\btruncate\b/, why: 'membuat atau mengubah file' },
  { re: /\bsed\s+-i\b|\bperl\s+-i\b/, why: 'mengedit file secara langsung' },
  { re: /\bgit\s+(commit|checkout|merge|rebase|stash|tag|branch)\b/, why: 'mengubah repositori Git' },
  { re: /\bnpm\s+(run|test|start|build|ci)\b|\bmake\b|\bpython3?\s+\S+\.py\b|\bnode\s+\S+\.(js|mjs|cjs)\b/, why: 'menjalankan program / skrip' },
  { re: /\bzip\b|\bunzip\b|\btar\b|\bgzip\b|\bgunzip\b/, why: 'mengemas / mengekstrak arsip' },
];

const LOW_RISK_ALLOWLIST = [
  /^ls\b/, /^pwd$/, /^cat\b/, /^head\b/, /^tail\b/, /^grep\b/, /^rg\b/, /^find\b/, /^wc\b/,
  /^echo\s+[^>]*$/, /^date$/, /^whoami$/, /^uname\b/, /^node\s+(-v|--version)\b/,
  /^git\s+(status|log|diff|show|remote|config\s+--get)\b/, /^du\b/, /^df\b/,
  /^which\b|^command\s+-v\b/,
];

/** True jika nama file berpotensi berisi kredensial/rahasia. */
function isSensitiveFile(absPath) {
  const base = path.basename(absPath);
  return SENSITIVE_FILE_PATTERNS.some((re) => re.test(base));
}

/** True jika path berada di dalam direktori .git (proteksi penulisan). */
function isProtectedDir(absPath) {
  const parts = absPath.split(path.sep);
  return parts.includes('.git');
}

/**
 * Resolve path relatif/absolut dan paksa tetap di dalam workspace.
 * Mencegah path traversal (../) dan symlink escape.
 * @returns {string} path absolut di dalam workspace
 * @throws {Error} jika keluar dari workspace
 */
function resolveInWorkspace(workspace, p) {
  if (!p || typeof p !== 'string' || !p.trim()) {
    throw new Error('Path tidak boleh kosong');
  }
  if (p.includes('\0')) throw new Error('Path tidak valid');
  const abs = path.isAbsolute(p) ? path.normalize(p) : path.resolve(workspace, p);

  let wsReal;
  try {
    wsReal = fs.realpathSync(workspace);
  } catch (e) {
    throw new Error('Workspace tidak dapat diakses: ' + e.message);
  }

  // Ikuti realpath untuk segmen yang sudah ada (cegah symlink keluar workspace)
  let check = abs;
  const extra = [];
  while (check !== path.dirname(check) && !fs.existsSync(check)) {
    extra.unshift(path.basename(check));
    check = path.dirname(check);
  }
  let real;
  try {
    real = fs.realpathSync(check);
  } catch (_) {
    real = check;
  }
  const full = extra.length ? path.join(real, ...extra) : real;

  const normWs = wsReal.endsWith(path.sep) ? wsReal : wsReal + path.sep;
  if (full !== wsReal && !full.startsWith(normWs)) {
    throw new Error('Akses di luar workspace tidak diizinkan: ' + p);
  }
  return full;
}

/**
 * Klasifikasikan risiko perintah shell.
 * @returns {{risk: 'low'|'medium'|'high', reasons: string[]}}
 */
function classifyCommand(cmd) {
  const c = String(cmd || '').trim();
  const reasons = [];
  for (const p of HIGH_RISK_PATTERNS) {
    if (p.re.test(c)) reasons.push(p.why);
  }
  if (reasons.length) return { risk: 'high', reasons };

  for (const p of MEDIUM_RISK_PATTERNS) {
    if (p.re.test(c)) reasons.push(p.why);
  }
  if (reasons.length) return { risk: 'medium', reasons };

  for (const re of LOW_RISK_ALLOWLIST) {
    if (re.test(c)) return { risk: 'low', reasons: ['membaca / menampilkan informasi saja'] };
  }
  return { risk: 'medium', reasons: ['efek perintah tidak dikenali - periksa manual'] };
}

/** Penjelasan singkat efek perintah untuk ditampilkan sebelum approval. */
function explainCommand(cmd) {
  const { risk, reasons } = classifyCommand(cmd);
  const label = { low: 'aman (baca-saja)', medium: 'perlu perhatian', high: 'berisiko' }[risk];
  return { risk, label, reasons };
}

module.exports = {
  isSensitiveFile,
  isProtectedDir,
  resolveInWorkspace,
  classifyCommand,
  explainCommand,
  SENSITIVE_FILE_PATTERNS,
};

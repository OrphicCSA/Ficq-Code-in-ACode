'use strict';

/**
 * Test runner FICQ Agent - tanpa dependensi eksternal.
 * Menjalankan semua skenario: unit + integrasi via mock HTTP server.
 * Jalankan: node tests/run-tests.js
 */

const os = require('os');
const fs = require('fs');
const path = require('path');
const http = require('http');

const { maskKey, redact } = require('../src/config/config');
const { ToolRegistry, normalizeSchema } = require('../src/tools/registry');
const { defineFilesystemTools } = require('../src/tools/filesystem');
const { defineTerminalTools } = require('../src/tools/terminal');
const { defineProjectTools } = require('../src/tools/project');
const { classifyCommand, resolveInWorkspace, isSensitiveFile } = require('../src/tools/safety');
const { Session, SessionStore } = require('../src/memory/session');
const { AgentCore } = require('../src/core/agent');
const { MockProvider } = require('../src/providers/mock');
const { GeminiProvider } = require('../src/providers/gemini');
const { estimateHistoryTokens, compactIfNeeded } = require('../src/core/context');

// ---------------------------------------------------------------- helpers

function assert(cond, msg) {
  if (!cond) throw new Error('Assert gagal: ' + msg);
}

function eq(a, b, msg) {
  if (a !== b) throw new Error('Assert gagal: ' + msg + ' (' + JSON.stringify(a) + ' !== ' + JSON.stringify(b) + ')');
}

function silentUI() {
  return {
    progress() {}, progressEnd() {}, toolStart() {}, toolDone() {},
    warn() {}, info() {}, error() {}, assistant() {}, approvalBox() {},
    prompt: (s) => s, banner() {},
  };
}

function fakeConfig(over) {
  const vals = Object.assign(
    {
      provider: 'gemini', model: 'test-model', baseUrl: '', maxIterations: 15,
      requestTimeoutMs: 5000, maxRetries: 1, retryDelayMs: 10, maxOutputTokens: 100,
      temperature: 0.4, maxToolOutputChars: 8000, commandTimeoutMs: 5000,
      contextTokenBudget: 6000, checkConnectionOnStart: false, maxFileSizeBytes: 100000, language: 'id',
    },
    over || {}
  );
  return { get: (k) => vals[k], set: (k, v) => { vals[k] = v; }, values: vals };
}

// Workspace sementara untuk seluruh pengujian
const tmpWS = fs.mkdtempSync(path.join(os.tmpdir(), 'ficq-test-'));
process.chdir(tmpWS);

// ---------------------------------------------------------------- mock server Gemini-compatible

function startMockGemini(steps) {
  const state = { requests: [], steps: steps.slice(), port: 0, server: null };
  state.server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      state.requests.push({ url: req.url, headers: req.headers, body });
      const step = state.steps.shift();
      if (!step) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: 'mock steps habis' } }));
        return;
      }
      if (step.status) {
        res.writeHead(step.status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(step.body || { error: { message: step.message || 'err' } }));
        return;
      }
      const parts = [];
      if (step.text) parts.push({ text: step.text });
      if (step.functionCall) parts.push({ functionCall: step.functionCall });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          candidates: [{ content: { parts, role: 'model' }, finishReason: 'STOP' }],
          usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 5, totalTokenCount: 15 },
        })
      );
    });
  });
  return new Promise((resolve) => {
    state.server.listen(0, '127.0.0.1', () => {
      state.port = state.server.address().port;
      state.url = 'http://127.0.0.1:' + state.port;
      resolve(state);
    });
  });
}

function stopMock(state) {
  return new Promise((r) => state.server.close(r));
}

function makeRegistry(config) {
  const reg = new ToolRegistry();
  defineFilesystemTools(reg, config);
  defineTerminalTools(reg, config);
  defineProjectTools(reg, config);
  return reg;
}

// ---------------------------------------------------------------- tests

const tests = [];

tests.push({
  name: 'config: redact & maskKey menyembunyikan API key',
  fn: async () => {
    const key = 'AIzaSyA1234567890abcdefghijklmnopQ';
    const out = redact('error dengan key ' + key + ' di dalamnya');
    assert(!out.includes(key), 'key masih bocor di redact()');
    assert(out.includes('AIza***REDACTED***'), 'redact() tidak menandai key');
    const m = maskKey(key);
    assert(!m.includes(key.slice(6, -4)), 'maskKey membocorkan isi key');
    assert(redact('Bearer abc.def.ghi').includes('***REDACTED***'), 'redact gagal untuk Bearer');
  },
});

tests.push({
  name: 'safety: path traversal diblokir, klasifikasi risiko perintah benar',
  fn: async () => {
    const inside = resolveInWorkspace(tmpWS, 'sub/dir/file.txt');
    assert(inside.startsWith(tmpWS), 'path di dalam workspace harus lolos');
    let threw = null;
    try {
      resolveInWorkspace(tmpWS, '../luar.txt');
    } catch (e) {
      threw = e;
    }
    assert(threw, 'path traversal ../ tidak ditolak');
    try {
      resolveInWorkspace(tmpWS, '/etc/passwd');
      throw new Error('absolut di luar workspace tidak ditolak');
    } catch (e) {
      assert(/di luar workspace/.test(e.message), 'pesan error absolut salah: ' + e.message);
    }
    eq(classifyCommand('ls -la').risk, 'low', 'ls harus low');
    eq(classifyCommand('cat src/index.js').risk, 'low', 'cat harus low');
    eq(classifyCommand('mkdir build').risk, 'medium', 'mkdir harus medium');
    eq(classifyCommand('rm -rf data').risk, 'high', 'rm harus high');
    eq(classifyCommand('curl https://x.com').risk, 'high', 'curl harus high');
    eq(classifyCommand('npm install left-pad').risk, 'high', 'npm install harus high');
    eq(classifyCommand('npm test').risk, 'medium', 'npm test harus medium');
    assert(isSensitiveFile('/x/.env'), '.env harus terdeteksi sensitif');
    assert(isSensitiveFile('/x/id_rsa'), 'id_rsa harus terdeteksi sensitif');
    assert(!isSensitiveFile('/x/index.js'), 'index.js tidak boleh dianggap sensitif');
  },
});

tests.push({
  name: 'registry: validasi argumen & normalisasi schema',
  fn: async () => {
    const reg = new ToolRegistry();
    reg.register({
      name: 'dummy_tool',
      description: 'tool uji',
      parameters: { type: 'object', properties: { path: { type: 'string' }, n: { type: 'integer' } }, required: ['path'] },
      needsApproval: false,
      execute: async (a) => ({ ok: true, data: a }),
    });
    eq(reg.validate('dummy_tool', {}).ok, false, 'required tidak divalidasi');
    eq(reg.validate('dummy_tool', { path: 'a', zz: 1 }).ok, false, 'param asing tidak ditolak');
    eq(reg.validate('dummy_tool', { path: 'a', n: 'bukan angka' }).ok, false, 'tipe salah tidak ditolak');
    eq(reg.validate('dummy_tool', { path: 'a' }).ok, true, 'args valid ditolak');
    eq(reg.validate('tool_tidak_ada', {}).ok, false, 'tool asing tidak ditolak');
    const ns = normalizeSchema({ type: 'string', description: 'x' });
    eq(ns.type, 'STRING', 'schema tipe string harus STRING');
    const nso = normalizeSchema({ type: 'object', properties: { p: { type: 'boolean' } }, required: ['p'] });
    eq(nso.type, 'OBJECT', 'schema tipe object harus OBJECT');
    eq(nso.properties.p.type, 'BOOLEAN', 'schema nested salah');
  },
});

tests.push({
  name: 'fs tools: write/read/edit/search/list bekerja & file rahasia ditolak',
  fn: async () => {
    const config = fakeConfig();
    const reg = makeRegistry(config);
    const ctx = { workspace: tmpWS, config, maxToolOutputChars: 8000 };

    let r = await reg.execute('write_file', { path: 'src/app.js', content: 'console.log(1);\n' }, ctx);
    eq(r.ok, true, 'write_file gagal: ' + (r.result && r.result.error));
    assert(fs.existsSync(path.join(tmpWS, 'src/app.js')), 'file tidak tercipta');

    r = await reg.execute('read_file', { path: 'src/app.js' }, ctx);
    eq(r.ok, true, 'read_file gagal');
    assert(r.result.data.content.includes('console.log(1)'), 'isi file salah');

    r = await reg.execute('edit_file', { path: 'src/app.js', old_text: 'console.log(1);', new_text: 'console.log(2);' }, ctx);
    eq(r.ok, true, 'edit_file gagal: ' + (r.result && r.result.error));
    assert(fs.readFileSync(path.join(tmpWS, 'src/app.js'), 'utf8').includes('console.log(2)'), 'edit tidak tersimpan');

    fs.writeFileSync(path.join(tmpWS, 'dup.txt'), 'x\nx\nx\n');
    r = await reg.execute('edit_file', { path: 'dup.txt', old_text: 'x', new_text: 'y' }, ctx);
    eq(r.ok, false, 'old_text ambigu harus ditolak');
    r = await reg.execute('edit_file', { path: 'dup.txt', old_text: 'x', new_text: 'y', replace_all: true }, ctx);
    eq(r.ok, true, 'replace_all gagal');

    fs.writeFileSync(path.join(tmpWS, '.env'), 'TOP_SECRET=1\n');
    r = await reg.execute('read_file', { path: '.env' }, ctx);
    eq(r.ok, false, 'read .env harus ditolak');
    assert(/kredensial/i.test(r.result.error), 'pesan penolakan .env tidak informatif');

    r = await reg.execute('search_files', { pattern: 'console.log' }, ctx);
    eq(r.ok, true, 'search_files gagal');
    assert(r.result.data.matches.some((m) => m.file.includes('app.js')), 'hasil search salah');

    r = await reg.execute('list_files', { path: '.' }, ctx);
    eq(r.ok, true, 'list_files gagal');
    assert(r.result.data.entries.length >= 2, 'list_files terlalu sedikit');
  },
});

tests.push({
  name: 'agent: percakapan teks biasa (tanpa tool)',
  fn: async () => {
    const provider = new MockProvider({ script: [{ text: 'Halo dunia' }] });
    const memory = new Session(null);
    const agent = new AgentCore({ provider, registry: makeRegistry(fakeConfig()), memory, config: fakeConfig(), ui: silentUI() });
    const answer = await agent.submit('hai');
    eq(answer, 'Halo dunia', 'jawaban salah');
    eq(memory.entries().length, 2, 'history harus 2 (user+model)');
    eq(memory.usage.apiRequests, 1, 'penggunaan API tidak tercatat');
    eq(memory.usage.totalTokens, 160, 'token tidak terakumulasi');
  },
});

tests.push({
  name: 'agent: tool calling penuh (write_file) + functionResponse kembali ke model',
  fn: async () => {
    const provider = new MockProvider({
      script: [
        { functionCalls: [{ name: 'write_file', args: { path: 'notes.txt', content: 'isi catatan' } }] },
        { text: 'File dibuat.' },
      ],
    });
    const memory = new Session(null);
    const agent = new AgentCore({ provider, registry: makeRegistry(fakeConfig()), memory, config: fakeConfig(), ui: silentUI() });
    agent.setApprover(async () => true);
    const answer = await agent.submit('buat notes.txt berisi "isi catatan"');
    eq(answer, 'File dibuat.', 'jawaban akhir salah');
    assert(fs.existsSync(path.join(tmpWS, 'notes.txt')), 'tool tidak benar-benar dieksekusi');
    eq(memory.usage.toolExecutions, 1, 'jumlah eksekusi tool salah');
    // Verifikasi bentuk history yang dikirim pada panggilan ke-2
    const h = provider.calls[1].history;
    eq(h[h.length - 2].type, 'calls', 'entry calls tidak ada');
    eq(h[h.length - 1].type, 'tool', 'entry tool result tidak ada');
    eq(h[h.length - 1].name, 'write_file', 'nama tool pada functionResponse salah');
    eq(h[h.length - 1].response.ok, true, 'response tool salah');
  },
});

tests.push({
  name: 'agent: penolakan persetujuan diteruskan ke model sebagai error',
  fn: async () => {
    const provider = new MockProvider({
      script: [
        { functionCalls: [{ name: 'run_command', args: { command: 'echo test-approval' } }] },
        { text: 'Baik, tidak jadi menjalankan.' },
      ],
    });
    const memory = new Session(null);
    const agent = new AgentCore({ provider, registry: makeRegistry(fakeConfig()), memory, config: fakeConfig(), ui: silentUI() });
    agent.setApprover(async () => false);
    await agent.submit('jalankan echo');
    const last = memory.entries()[memory.entries().length - 2]; // entry tool sebelum jawaban model
    eq(last.type, 'tool', 'harus ada entry tool');
    eq(last.response.ok, false, 'penolakan harus menghasilkan ok:false');
    assert(/MENOLAK/i.test(last.response.error), 'pesan penolakan tidak jelas');
  },
});

tests.push({
  name: 'agent: batas iterasi menghentikan infinite loop',
  fn: async () => {
    const provider = new MockProvider({
      script: [
        { functionCalls: [{ name: 'list_files', args: { path: '.' } }] },
        { functionCalls: [{ name: 'list_files', args: { path: '.' } }] },
      ],
    });
    const memory = new Session(null);
    const config = fakeConfig({ maxIterations: 2 });
    const agent = new AgentCore({ provider, registry: makeRegistry(config), memory, config, ui: silentUI() });
    agent.setApprover(async () => true);
    let err = null;
    try {
      await agent.submit('loop terus');
    } catch (e) {
      err = e;
    }
    assert(err, 'harus melempar error batas iterasi');
    assert(/Batas iterasi/.test(err.message), 'pesan batas iterasi salah: ' + err.message);
  },
});

tests.push({
  name: 'gemini provider: integrasi HTTP nyata (header key, mapping contents, parsing)',
  fn: async () => {
    const state = await startMockGemini([{ text: 'Halo dari mock HTTP' }]);
    try {
      const config = fakeConfig({ requestTimeoutMs: 5000, maxRetries: 0 });
      const provider = new GeminiProvider({ apiKey: 'test-key-123', model: 'test-model', baseUrl: state.url, config });
      const history = [
        { type: 'text', role: 'user', text: 'hai' },
        { type: 'calls', role: 'model', calls: [{ name: 'list_files', args: { path: '.' } }] },
        { type: 'tool', name: 'list_files', response: { ok: true, data: { entries: [] } } },
        { type: 'text', role: 'model', text: 'selesai' },
        { type: 'text', role: 'user', text: 'lanjut' },
      ];
      const toolDecls = [
        { name: 'list_files', description: 'd', parameters: { type: 'OBJECT', properties: { path: { type: 'STRING' } }, required: ['path'] } },
      ];
      const resp = await provider.generate({ system: 'SYS', history, toolDecls });
      eq(resp.text, 'Halo dari mock HTTP', 'teks respons salah');
      eq(resp.usage.total, 15, 'usage salah');

      const req = state.requests[0];
      eq(req.headers['x-goog-api-key'], 'test-key-123', 'header API key salah');
      const body = JSON.parse(req.body);
      eq(body.contents.length, 5, 'jumlah contents salah');
      eq(body.contents[0].role, 'user', 'role user salah');
      eq(body.contents[0].parts[0].text, 'hai', 'text part salah');
      eq(body.contents[1].parts[0].functionCall.name, 'list_files', 'functionCall mapping salah');
      eq(body.contents[2].parts[0].functionResponse.name, 'list_files', 'functionResponse name salah');
      eq(typeof body.contents[2].parts[0].functionResponse.response, 'object', 'functionResponse.response harus object');
      eq(body.contents[3].role, 'model', 'role model salah');
      eq(body.systemInstruction.parts[0].text, 'SYS', 'systemInstruction salah');
      eq(body.tools[0].functionDeclarations[0].name, 'list_files', 'functionDeclarations salah');
      assert(req.url.includes('/v1beta/models/test-model:generateContent'), 'URL endpoint salah: ' + req.url);

      // functionCall parsing
      const state2 = await startMockGemini([{ functionCall: { name: 'read_file', args: { path: 'a.js' } } }]);
      try {
        const p2 = new GeminiProvider({ apiKey: 'k', model: 'm', baseUrl: state2.url, config });
        const r2 = await p2.generate({ system: 's', history: [{ type: 'text', role: 'user', text: 'x' }] });
        eq(r2.functionCalls.length, 1, 'functionCall tidak terdeteksi');
        eq(r2.functionCalls[0].name, 'read_file', 'nama functionCall salah');
        eq(r2.functionCalls[0].args.path, 'a.js', 'args functionCall salah');
      } finally {
        await stopMock(state2);
      }
    } finally {
      await stopMock(state);
    }
  },
});

tests.push({
  name: 'gemini provider: error API dipetakan & key tidak pernah muncul di pesan error',
  fn: async () => {
    const state = await startMockGemini([{ status: 400, body: { error: { message: 'API key not valid. Please pass a valid API key.' } } }]);
    try {
      const config = fakeConfig({ requestTimeoutMs: 5000, maxRetries: 0 });
      const provider = new GeminiProvider({ apiKey: 'AIzaSUPERSECRET123', model: 'm', baseUrl: state.url, config });
      let err = null;
      try {
        await provider.generate({ system: 's', history: [{ type: 'text', role: 'user', text: 'x' }] });
      } catch (e) {
        err = e;
      }
      assert(err, 'harus melempar error');
      assert(/API key tidak valid/.test(err.message), 'pesan error 400 tidak dipetakan: ' + err.message);
      assert(!err.message.includes('AIzaSUPERSECRET123'), 'API key bocor di pesan error!');
    } finally {
      await stopMock(state);
    }
  },
});

tests.push({
  name: 'gemini provider: 429 di-retry lalu sukses',
  fn: async () => {
    const state = await startMockGemini([
      { status: 429, body: { error: { message: 'Resource exhausted' } } },
      { text: 'ok setelah retry' },
    ]);
    try {
      const config = fakeConfig({ requestTimeoutMs: 5000, maxRetries: 1, retryDelayMs: 10 });
      const provider = new GeminiProvider({ apiKey: 'k', model: 'm', baseUrl: state.url, config });
      const resp = await provider.generate({ system: 's', history: [{ type: 'text', role: 'user', text: 'x' }] });
      eq(resp.text, 'ok setelah retry', 'retry tidak berhasil');
      eq(state.requests.length, 2, 'jumlah request setelah retry salah');
    } finally {
      await stopMock(state);
    }
  },
});

tests.push({
  name: 'session: simpan/muat, usage terakumulasi, tanpa API key di dalamnya',
  fn: async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ficq-sesi-'));
    const store = new SessionStore({ dir });
    const s = store.create({ model: 'm1', provider: 'gemini', workspace: tmpWS });
    s.appendText('user', 'halo');
    s.appendText('model', 'hai juga');
    s.addUsage({ input: 10, output: 5, total: 15 });
    store.save(s);
    const l = store.list();
    eq(l.length, 1, 'sesi tidak tercatat di list');
    const loaded = store.load(s.id);
    eq(loaded.entries().length, 2, 'riwayat tidak termuat');
    eq(loaded.usage.totalTokens, 15, 'usage tidak termuat');
    const raw = fs.readFileSync(path.join(dir, 'sesi-' + s.id + '.json'), 'utf8');
    assert(!raw.includes('AIzaTESTKEY'), 'API key tidak boleh ada di file sesi');
  },
});

tests.push({
  name: 'context: compaction memicu ringkasan & menjaga pesan terakhir',
  fn: async () => {
    const provider = new MockProvider({ script: [{ text: 'RINGKASAN-OK' }] });
    const memory = new Session(null);
    for (let i = 0; i < 3; i++) memory.appendText('user', 'Pesan panjang ke-' + i + ' '.repeat(600) + 'x');
    memory.appendText('model', 'jawaban');
    const config = fakeConfig({ contextTokenBudget: 100 });
    const res = await compactIfNeeded({ memory, provider, config, ui: silentUI() });
    eq(res.compacted, true, 'compaction tidak terjadi');
    const entries = memory.entries();
    eq(entries[0].type, 'summary', 'entri pertama harus summary');
    assert(entries[0].text.includes('RINGKASAN-OK'), 'ringkasan tidak berasal dari model');
    eq(entries[entries.length - 1].role, 'model', 'pesan terakhir harus dipertahankan');
    // 40 karakter + overhead 24 per entri = 64 -> 16 token
    eq(estimateHistoryTokens([{ type: 'text', role: 'user', text: 'a'.repeat(40) }]), 16, 'estimasi token salah');
  },
});

tests.push({
  name: 'terminal & project: run_command, get_environment, git_status, run_tests',
  fn: async () => {
    const config = fakeConfig();
    const reg = makeRegistry(config);
    const ctx = { workspace: tmpWS, config, maxToolOutputChars: 8000 };

    let r = await reg.execute('run_command', { command: 'echo halo-ficq' }, ctx);
    eq(r.ok, true, 'run_command gagal');
    assert(r.result.data.stdout.includes('halo-ficq'), 'stdout tidak tertangkap');

    r = await reg.execute('run_command', { command: 'exit 3' }, ctx);
    eq(r.ok, false, 'perintah gagal harus ok:false');
    eq(r.result.data.exitCode, 3, 'exit code salah');

    r = await reg.execute('get_environment', {}, ctx);
    eq(r.ok, true, 'get_environment gagal');
    assert(r.result.data.nodeVersion.startsWith('v'), 'nodeVersion salah');

    r = await reg.execute('git_status', {}, ctx);
    eq(r.ok, false, 'git_status di folder bukan repo harus ok:false');
    assert(/bukan repositori|git/i.test(r.result.error), 'pesan git_status salah');

    r = await reg.execute('run_tests', {}, ctx);
    eq(r.ok, false, 'run_tests tanpa konfigurasi test harus ok:false');
  },
});

// ---------------------------------------------------------------- runner

(async () => {
  let pass = 0;
  let fail = 0;
  for (const t of tests) {
    try {
      await t.fn();
      pass++;
      process.stdout.write('  PASS  ' + t.name + '\n');
    } catch (e) {
      fail++;
      process.stdout.write('  FAIL  ' + t.name + '\n        ' + e.message + '\n');
    }
  }
  process.stdout.write('\n' + pass + ' lulus, ' + fail + ' gagal (workspace uji: ' + tmpWS + ')\n');
  process.exit(fail ? 1 : 0);
})();

#!/bin/sh
# FICQ Agent - instalasi untuk Acode/Android (Alpine proot) dan Linux umum.
# FICQ Agent TIDAK butuh dependensi npm apa pun - hanya Node.js >= 16.

set -e

echo "== FICQ Agent installer =="

# 1. Node.js
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js tidak ditemukan. Mencoba memasang via package manager..."
  if command -v apk >/dev/null 2>&1; then
    apk add --no-cache nodejs npm
  elif command -v apt-get >/dev/null 2>&1; then
    apt-get update && apt-get install -y nodejs npm
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y nodejs npm
  else
    echo "GAGAL: tidak ada package manager yang dikenali (apk/apt/dnf)."
    echo "Pasang Node.js >= 16 manual, lalu jalankan ulang skrip ini."
    exit 1
  fi
fi

NODE_MAJOR=$(node -e 'console.log(process.versions.node.split(".")[0])' 2>/dev/null || echo 0)
if [ "$NODE_MAJOR" -lt 16 ]; then
  echo "PERINGATAN: Node.js $(node --version) < 16. FICQ membutuhkan Node >= 16."
  echo "Di Alpine: apk add nodejs npm"
  exit 1
fi
echo "Node.js $(node --version) OK"

# 2. Pastikan berada di folder proyek
if [ ! -f index.js ]; then
  echo "GAGAL: index.js tidak ditemukan. Jalankan installer dari folder ficq-agent."
  exit 1
fi
chmod +x index.js

# 3. Tidak ada npm install (nol dependensi)
echo "FICQ Agent tanpa dependensi npm - langkah npm install dilewati."

# 4. API key
if [ -n "$GEMINI_API_KEY" ] || [ -f "$HOME/.ficq/secret" ]; then
  echo "API key : terdeteksi (isinya tidak ditampilkan)."
else
  echo "API key : BELUM dikonfigurasi."
  echo "  1. Buat key gratis di https://aistudio.google.com/apikey"
  echo "  2. Simpan tanpa menampilkannya:"
  echo "       node index.js --set-key"
  echo "     atau per sesi terminal:"
  echo "       export GEMINI_API_KEY=\"key-anda\""
fi

echo ""
echo "Instalasi selesai. Cara pakai dari folder proyek Anda:"
echo "  node /path/ke/ficq-agent/index.js"
echo ""
echo "Opsional - buat alias permanen, tambahkan ke ~/.profile:"
echo "  alias ficq='node /path/ke/ficq-agent/index.js'"

#!/bin/sh
# FICQ Agent - pemeriksaan lingkungan (Acode/Android/Alpine proot).
# Aman dijalankan di mana saja, selalu exit 0, tidak mengubah apa pun.

bold() { printf '%s\n' "=== $1 ==="; }
sep() { printf '------------------------------------------------------------\n'; }

sep; bold "SISTEM"; sep
uname -a 2>/dev/null
echo "Arsitektur : $(uname -m)"
head -3 /etc/os-release 2>/dev/null
echo "Pengguna   : $(id -un 2>/dev/null || echo '?')"

sep; bold "RUNTIME"; sep
for c in node npm python3 pip3 git curl wget; do
  if command -v "$c" >/dev/null 2>&1; then
    v=$("$c" --version 2>/dev/null | head -n 1)
    echo "$c : ADA ($v)"
  else
    echo "$c : TIDAK ADA"
  fi
done

if command -v node >/dev/null 2>&1; then
  NODE_MAJOR=$(node -e 'console.log(process.versions.node.split(".")[0])' 2>/dev/null || echo 0)
  if [ "$NODE_MAJOR" -ge 16 ] 2>/dev/null; then
    echo "Node.js OK (>= 16) - FICQ Agent kompatibel"
  else
    echo "PERINGATAN: Node.js terlalu lama. FICQ butuh Node >= 16."
    echo "  Alpine : apk add nodejs npm"
  fi
else
  echo "Node.js belum terpasang. Di Alpine: apk add nodejs npm"
fi

sep; bold "PACKAGE MANAGER"; sep
found=0
for pm in apk apt dnf pkg; do
  if command -v "$pm" >/dev/null 2>&1; then
    echo "$pm : ADA"
    found=1
  fi
done
[ "$found" = 0 ] && echo "Tidak ada package manager dikenali (apk/apt/dnf/pkg)"

sep; bold "MEMORI"; sep
if [ -r /proc/meminfo ]; then
  awk '/MemTotal/ {printf "Total    : %.0f MB\n", $2/1024} /MemAvailable/ {printf "Tersedia : %.0f MB\n", $2/1024}' /proc/meminfo
elif command -v free >/dev/null 2>&1; then
  free -m
else
  echo "Tidak bisa membaca info memori"
fi

sep; bold "DISK (direktori sekarang)"; sep
df -h . 2>/dev/null | tail -n 1

sep; bold "JARINGAN (API Gemini)"; sep
if command -v node >/dev/null 2>&1; then
  node -e "require('dns').lookup('generativelanguage.googleapis.com',(e,a)=>{console.log(e?('DNS GAGAL: '+e.code):('DNS OK ('+a+')'));process.exit(0)})" 2>/dev/null || echo "Tes DNS gagal dijalankan"
else
  echo "(butuh node untuk tes DNS)"
fi

sep; bold "API KEY (tidak ditampilkan isinya)"; sep
if [ -n "$GEMINI_API_KEY" ]; then
  echo "GEMINI_API_KEY : terpasang (env)"
else
  echo "GEMINI_API_KEY : belum di-set di environment"
fi
if [ -f "$HOME/.ficq/secret" ]; then
  echo "File secret    : ada (~/.ficq/secret)"
else
  echo "File secret    : tidak ada"
fi

sep
echo "Selesai. Lampirkan output ini jika meminta bantuan kompatibilitas."
exit 0
